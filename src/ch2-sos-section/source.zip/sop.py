import sys; sys.path.insert(0, "/home/claude/work/figsrc")
from style import *
import numpy as np
from matplotlib.patches import FancyArrowPatch, Rectangle, FancyBboxPatch
rng = np.random.default_rng(4)
fig = plt.figure(figsize=(6.3, 2.05))
ax = fig.add_axes([0.0, 0.0, 0.56, 1.0]); ax.set_xlim(0, 10); ax.set_ylim(0, 5.6); ax.axis("off")
ax.add_patch(Rectangle((0.3, 0.35), 9.4, 0.55, fc="#C9C1B8", ec="none"))
ax.text(5.0, 0.62, "substrate", ha="center", va="center", fontsize=10.5, color=INK)
ax.add_patch(Rectangle((0.3, 0.9), 9.4, 3.75, fc="#F1ECE6", ec="none"))
xs, ys = np.meshgrid(np.linspace(0.9, 9.1, 9), np.linspace(1.45, 4.1, 4))
for x, y in zip(xs.ravel() + rng.uniform(-0.2, 0.2, xs.size), ys.ravel() + rng.uniform(-0.12, 0.12, xs.size)):
    th = rng.normal(0, 55)  # angle from the surface normal, biased upward (schematic)
    dx, dy = 0.42 * np.sin(np.radians(th)), 0.42 * np.cos(np.radians(th))
    ax.add_patch(FancyArrowPatch((x - dx, y - dy), (x + dx, y + dy), arrowstyle="-|>,head_length=0.35,head_width=0.2", mutation_scale=12, lw=1.6, color=CLAY))
for x in np.linspace(0.8, 9.2, 13):
    ax.text(x, 4.95, "+", ha="center", va="center", fontsize=13, color=CRIMSON, fontweight="bold")
ax.text(9.75, 5.05, "", ha="right")
ax.text(0.3, 5.45, "Evaporated film, each molecule a permanent dipole", ha="left", va="center", fontsize=10.5, color=SLATE)
# surface potential versus thickness
ax2 = fig.add_axes([0.70, 0.27, 0.28, 0.62])
t = np.array([0, 560.0]); v = np.array([0, 28.0])
ax2.plot(t, v, color=CLAY, lw=2.0); ax2.plot([560], [28], "o", color=CLAY, ms=5)
ax2.set_xlim(0, 600); ax2.set_ylim(0, 32); ax2.set_xticks([0, 200, 400, 600]); ax2.set_yticks([0, 10, 20, 30])
ax2.set_xlabel("Thickness (nm)", fontsize=10.5); ax2.set_ylabel("Surface potential (V)", fontsize=10.5); ax2.tick_params(labelsize=9.5)
ax2.text(545, 29.5, "28 V", ha="right", va="bottom", fontsize=10.5, color=CLAY)
ax2.text(0.0, 1.07, "Ito et al. (2002)", transform=ax2.transAxes, fontsize=10, color=SLATE, style="italic")
fig.savefig("/home/claude/work/figs/alq3-sop.png", dpi=300)
