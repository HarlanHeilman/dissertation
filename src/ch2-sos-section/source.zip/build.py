"""Rebuild the Chapter 2 (Alq3 and ZnPc) section of the defense deck."""
import copy
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN

F = "/home/claude/work/figs/"
prs = Presentation("/home/claude/work/stage1.pptx")
S = prs.slides
RED, INK, SLATE = RGBColor(0xCA, 0x12, 0x37), RGBColor(0x1F, 0x1F, 0x1F), RGBColor(0x5E, 0x6A, 0x71)


def shp(slide, sid=None, name=None):
    for s in slide.shapes:
        if (sid is not None and s.shape_id == sid) or (name is not None and s.name == name):
            return s
    raise KeyError((sid, name))


def set_text(shape, *paras):
    """Replace text keeping the first run's formatting of each existing paragraph."""
    tf = shape.text_frame
    ps = tf.paragraphs
    for i, txt in enumerate(paras):
        if i < len(ps):
            p = ps[i]
        else:
            new = copy.deepcopy(ps[-1]._p)
            tf._txBody.append(new)
            p = tf.paragraphs[-1]
        runs = p.runs
        runs[0].text = txt
        for r in runs[1:]:
            r._r.getparent().remove(r._r)
    for p in tf.paragraphs[len(paras):]:
        p._p.getparent().remove(p._p)


def remove(shape):
    shape._element.getparent().remove(shape._element)


def place(shape, x, y, w=None, h=None):
    shape.left, shape.top = Inches(x), Inches(y)
    if w is not None:
        shape.width = Inches(w)
    if h is not None:
        shape.height = Inches(h)


def picture(slide, path, x, y, w=None, h=None, descr="", after=None):
    pic = slide.shapes.add_picture(path, Inches(x), Inches(y), Inches(w) if w else None, Inches(h) if h else None)
    pic._element.nvPicPr.cNvPr.set("descr", descr)
    if after is not None:  # keep z-order just above `after`
        after._element.addnext(pic._element)
    return pic


def fit(path, x, y, w, h):
    from PIL import Image
    iw, ih = Image.open(path).size
    a = iw / ih
    if w / h > a:
        nw, nh = h * a, h
    else:
        nw, nh = w, w / a
    return x + (w - nw) / 2, y + (h - nh) / 2, nw, nh


def textbox(slide, x, y, w, h, runs, size=12, color=SLATE, bold=False, italic=False):
    tb = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = tb.text_frame
    tf.word_wrap = True
    for m in ("margin_left", "margin_right", "margin_top", "margin_bottom"):
        setattr(tf, m, 0)
    p = tf.paragraphs[0]
    r = p.add_run()
    r.text = runs
    r.font.size, r.font.bold, r.font.italic = Pt(size), bold, italic
    r.font.color.rgb = color
    return tb


def notes(slide, text):
    ns = slide.notes_slide
    if ns.notes_text_frame is None:
        ref = S[28].notes_slide  # existing notes slide with a body placeholder
        body = [sp for sp in ref.placeholders if sp.placeholder_format.type is not None and "BODY" in str(sp.placeholder_format.type)][0]
        ns.shapes._spTree.append(copy.deepcopy(body._element))
    tf = ns.notes_text_frame
    tf.text = text


def clone_after(shape, ref):
    el = copy.deepcopy(shape._element)
    ref._element.addnext(el)
    return el


# ---------------------------------------------------------------- 23 Alq3 introduction
s = S[22]
set_text(shp(s, name="Title 1"), "Alq3, a molecule with strange optical properties")
remove(shp(s, name="Picture 7"))
card = shp(s, name="Card")
x, y, w, h = fit(F + "alq3-isomers-3d.png", 0.95, 2.05, 6.30, 2.75)
picture(s, F + "alq3-isomers-3d.png", x, y, w, h, "Optimized mer and fac Alq3 with their permanent dipoles, 4.4 D and 7.1 D", after=card)
x, y, w, h = fit(F + "alq3-sop.png", 0.95, 4.85, 6.30, 2.05)
picture(s, F + "alq3-sop.png", x, y, w, h, "Schematic of spontaneous orientation polarization in an evaporated Alq3 film, and the surface potential growing to 28 V at 560 nm", after=card)
set_text(shp(s, sid=9), "Why the interfacial state may differ from the bulk")
rows = [
    (10, 11, 12, "Surface potential", "Spontaneous orientation polarization builds 28 V across 560 nm (Ito 2002)"),
    (13, 14, 15, "Hybridization", "The first layer on a metal mixes with its states, as in Co/Alq3 spin valves (Droghetti 2016)"),
    (16, 17, 18, "Conformation", "mer and fac isomers, with different dipoles and ligands free to twist about Al"),
]
for k, (b, t, d, title, body) in enumerate(rows):
    y0 = 2.45 + 1.0 * k
    place(shp(s, sid=b), 7.70, y0)
    place(shp(s, sid=t), 8.17, y0 + 0.02)
    place(shp(s, sid=d), 8.17, y0 + 0.34)
    set_text(shp(s, sid=t), title)
    set_text(shp(s, sid=d), body)
place(shp(s, sid=19), 7.70, 5.50, 4.85, 1.45)
place(shp(s, sid=20), 7.90, 5.50, 4.45, 1.45)
set_text(shp(s, sid=20), "An initial test of the method",
         "The films show no dichroism, so refining only the strength of each resonance isolates changes in electronic state.")
notes(s, """TIME 1.25 min

SOURCE Dissertation Chapter 2 (Alq3 growth paragraph) and Chapter 5 Methods (TEY at 30, 55 and 70 degrees, no dichroism). mer and fac geometries built for the defense and optimized with GFN2-xTB (tblite), dipoles 4.4 D (mer) and 7.1 D (fac) from the same calculation; these are not the StoBe als3-001 geometry. Film panel is a schematic. Surface potential line drawn from Ito et al., J. Appl. Phys. 92, 7306 (2002), 28 V at 560 nm, linear growth with thickness. Droghetti et al., Nat. Commun. 7, 12668 (2016).

SCRIPT The second molecule is Alq3, three quinolinolate ligands bound to an aluminum center through one oxygen and one nitrogen each. It was the emitter and electron transporter of the first efficient OLED and is still a standard molecule in organic spin valves. Three effects make its interfacial state a real question. First, the molecule carries a permanent dipole, and evaporating a film orients those dipoles slightly toward the surface normal. The bias is small, but it adds up layer by layer, so the surface potential grows linearly with thickness, 28 volts across 560 nanometers. That is spontaneous orientation polarization. Second, the first layer on a metal hybridizes with it, which is what makes Alq3 spin valves work. Third, the molecule is not rigid. It has mer and fac isomers, shown here as optimized structures, and the ligands can twist about the metal. The fac isomer has the larger dipole, 7.1 against 4.4 Debye in our calculation. Any of these can change the unoccupied orbitals the core electron is excited into. Our films show no dichroism, so orientation drops out, and refining only the strength of each resonance isolates a change in electronic state. That makes Alq3 the initial test.

TRANSITION How would we normally get its optical constants?""")

# ---------------------------------------------------------------- 24 problem slide
s = S[23]
set_text(shp(s, name="Title 1"), "WHERE RSOXS GETS ITS OPTICAL CONSTANTS")
for pid in (21, 27):  # old column C pictures
    remove(shp(s, sid=pid))
for pid in (17, 18):  # reflectivity measurement figures to column B
    p = shp(s, sid=pid); p.left = p.left + Inches(3.97)
for pid in (22, 24):  # co-refinement figures to column C
    p = shp(s, sid=pid); p.left = p.left + Inches(4.04)
set_text(shp(s, sid=33), "Borrow a reference film")
set_text(shp(s, sid=37), "Measure by reflectivity")
set_text(shp(s, sid=41), "Co-refine with structure")
set_text(shp(s, sid=20), "Assumes every film matches the reference")
set_text(shp(s, sid=46), "High uncertainty & still needs good films")
set_text(shp(s, sid=48), "Parameter explosion & no KK consistency")
cardA = shp(s, sid=29)
textbox(s, 0.98, 2.62, 3.30, 0.62, "NEXAFS of a reference film gives β, and Kramers-Kronig gives δ", size=13, color=INK)
x, y, w, h = fit(F + "alq3-two-films.png", 0.95, 3.35, 3.35, 2.65)
picture(s, F + "alq3-two-films.png", x, y, w, h, "Carbon K-edge beta of a 100 nm and a 20 nm Alq3 film", after=cardA)
textbox(s, 0.98, 6.08, 3.30, 0.45, "Two Alq3 films grown under nominally identical conditions", size=11, color=SLATE, italic=True)
notes(s, """TIME 1.25 min

SOURCE Column A, 100 nm film (NSLS-II, Alq3_model_oc) and 20 nm film (ALS TEY, Dec 2025), raw energies, the 20 nm film mapped onto the 100 nm pre-edge (below 280 eV) and post-edge (312 to 320 eV) levels. Columns B and C, the literature figures from the previous version of this slide. Dissertation Chapter 1 (standards and the parameter explosion) and Chapter 5 Introduction.

SCRIPT RSoXS needs optical constants, and there are three ways to get them. The standard one borrows them. Measure NEXAFS on a reference film, take beta, and Kramers-Kronig it for delta. That assumes every film of a molecule is the same. Here are two Alq3 films grown under nominally identical conditions. The relative peak heights differ throughout the pi star region, and the 284 eV transition is weaker in the thin film. Which one is the film we measure by reflectivity? The second route measures the constants directly from reflectivity, but the uncertainty is large and it still needs ideal films. The third co-refines the constants with the structure, beta and delta free at every energy and in every slab. Every new energy adds four parameters per slab, and nothing ties the constants at one energy to those at another, so the result need not be causal.

TRANSITION So instead we compose the response from the resonances that set it.""")

# ---------------------------------------------------------------- 25 building blocks
s = S[24]
set_text(shp(s, name="Title 1"), "Oscillators and the ionization edge")
for pid, path, d in ((43, "sos-one-resonance.png", "A Gaussian beta and its Dawson delta for one resonance, against a Lorentz oscillator of equal width"),
                     (46, "sos-ionization-edge.png", "The Alq3 carbon ionization edge, an erf step in beta and its Kramers-Kronig delta, IP at 290.8 eV")):
    old = shp(s, sid=pid)
    x = 5.90 if pid == 43 else 9.30
    picture(s, F + path, x, 1.95, 3.45, 3.45 * 1.5, d, after=old)
    remove(old)
notes(s, """TIME 1.5 min

SOURCE Static figures made for the defense. Left, a unit Gaussian and its Dawson partner against a Lorentz oscillator of equal FWHM (1 eV). Right, the Alq3 continuum of the exported best fit (bulk tensor minus its peaks), erf step at the mean StoBe site ionization potential, 290.8 eV, width 0.70 eV. Dissertation Chapter 2 oscillator section and Chapter 5 Methods.

SCRIPT Each resonance is a driven, damped oscillator along its transition dipole. A single lifetime-broadened oscillator gives a Lorentzian, but in a film the resonances are broadened mostly by vibrational structure, inequivalent sites and resolution, so we use a Gaussian absorption. Its Kramers-Kronig partner is the Dawson function, analytic, with no numerical transform. Each pair has three numbers, an energy, a width and a strength. The second building block is the ionization edge, an erf step at the ionization potential, here 290.8 eV from the DFT core-hole sites, sitting on the bare-atom background. Its delta comes from one Kramers-Kronig transform done once.

TRANSITION Summing these pieces gives the optical response of the whole molecule.""")

# ---------------------------------------------------------------- 26 composition
s = S[25]
set_text(shp(s, name="Title 1"), "Composing Alq3 from its resonances")
remove(shp(s, name="Picture 7"))
card = shp(s, name="Card")
place(card, 0.80, 2.00, 7.25, 4.95)
x, y, w, h = fit(F + "sos-alq3-composition.png", 0.92, 2.10, 7.00, 4.75)
picture(s, F + "sos-alq3-composition.png", x, y, w, h,
        "Alq3 beta and delta composed from 17 Gaussian-Dawson resonances on the ionization edge, with the ML-DFT resonators above", after=card)
hdr = shp(s, sid=9)
place(hdr, 8.30, 2.00, 4.25)
set_text(hdr, "One oscillator per ML-DFT cluster, on the edge")
rows = [
    (10, 11, 12, "Resonances", "17 clusters, each an energy, width, strength, and dipole"),
    (13, 14, 15, "Ionization edge", "erf step at the mean DFT ionization potential, 290.8 eV"),
    (16, 17, 18, "Sum", "β and δ add term by term, so every trial spectrum is causal"),
]
for k, (b, t, d, title, body) in enumerate(rows):
    y0 = 2.45 + 0.95 * k
    place(shp(s, sid=b), 8.30, y0)
    place(shp(s, sid=t), 8.77, y0 + 0.02, 3.78)
    place(shp(s, sid=d), 8.77, y0 + 0.34, 3.78)
    set_text(shp(s, sid=t), title)
    set_text(shp(s, sid=d), body)
place(shp(s, sid=19), 8.30, 5.40, 4.25, 1.55)
place(shp(s, sid=20), 8.48, 5.40, 3.90, 1.55)
set_text(shp(s, sid=20), "Parameters follow the transitions, not the energies",
         "Three per resonance, against four per energy per slab when β and δ are fit freely.")
notes(s, """TIME 1.5 min

SOURCE Alq3 export (alq3_best_fit_export, step 6), 17 Gaussian-Dawson pairs at their seed heights in the bulk, on the exported continuum. Arrows above the spectrum mark the ML-DFT cluster energies, length proportional to the square root of the integrated strength (amplitude times width). Dissertation Chapter 5 Methods and Fig. 5.2c.

SCRIPT Here is the whole Alq3 carbon edge built that way. Each arrow on top is one ML-DFT cluster, a family of transitions sharing an energy and a dipole. Each becomes one Gaussian in beta, the red shading, and one Dawson function in delta, the blue shading. Add the edge and you have the full spectrum, beta in black on top, delta in black below. Because every piece is a causal pair, any spectrum this model can produce obeys Kramers-Kronig, at every energy, whether we measured it or not. And the parameter count is set by the molecule. Three numbers per resonance, plus a dipole direction, where fitting beta and delta freely costs four numbers per energy per slab.

TRANSITION So what do the films look like in this basis?""")

# ---------------------------------------------------------------- 29 depth profile transition update
s = S[28]
t = s.notes_slide.notes_text_frame.text
s.notes_slide.notes_text_frame.text = t.replace("TRANSITION That open question carries into the next section.",
                                                "TRANSITION ZnPc asks the same question of the dipoles instead of the strengths.")

# ---------------------------------------------------------------- 30 ZnPc, what we fit
s = S[29]
set_text(shp(s, name="Title 1"), "Refining the dipoles of ZnPc")
remove(shp(s, name="Picture 7")); remove(shp(s, name="Picture 9")); remove(shp(s, sid=9))
card = shp(s, sid=7)
place(card, 0.80, 2.00, 11.75, 3.35)
x, y, w, h = fit(F + "znpc-tdm-frames.png", 1.20, 2.12, 10.95, 3.10)
picture(s, F + "znpc-tdm-frames.png", x, y, w, h, "Transition dipole at cone angle theta in the molecular frame, and the cone it sweeps in the film frame", after=card)
steps = [(11, 12, 13, "Start", "Chapter 4 structure, every cluster at its NEXAFS-refined seed."),
         (14, 15, 16, "Free", "One cone angle ϑ per π* cluster nearest a measured energy, at each interface and in the bulk."),
         (17, 18, 19, "Hold", "Energy, width, and height of every cluster stay at the seed.")]
for k, (bb, tt, dd, title, body) in enumerate(steps):
    x0 = 0.80 + 4.05 * k
    place(shp(s, sid=bb), x0, 5.62)
    place(shp(s, sid=tt), x0 + 0.45, 5.64, 3.25)
    place(shp(s, sid=dd), x0 + 0.45, 5.98, 3.25)
    set_text(shp(s, sid=tt), title); set_text(shp(s, sid=dd), body)
notes(s, """TIME 1.5 min

SOURCE Manuscript fig2 panels e and f. Confirm the three steps against the TDM-only refit (cone angles free, heights held) once it is run.

SCRIPT ZnPc is the opposite case to Alq3. Its films are strongly oriented, so the question is not how strong each resonance is but which way its dipole points. We keep the structure from Chapter 4 and every cluster at its NEXAFS-refined seed. For each pi star cluster nearest a measured energy we free one number, the cone angle theta between its dipole and the molecular normal, with a value at each interface and in the bulk. Energies, widths and heights stay where they are.

TRANSITION So what does the film do with that freedom?""")

# ---------------------------------------------------------------- 31 ZnPc dipole profile
s = S[30]
set_text(shp(s, name="Title 1"), "Optical reorganization through the film")
remove(shp(s, name="Picture 7"))
card = shp(s, name="Card")
place(card, 0.80, 2.00, 8.40, 4.95)
x, y, w, h = fit(F + "znpc-fig4-full.png", 0.92, 2.08, 8.16, 4.79)
picture(s, F + "znpc-fig4-full.png", x, y, w, h, "ZnPc reflectivity with the SOS and static fits, the molecular-frame beta and delta through depth, and the density and tilt profiles", after=card)
for sid in range(10, 19):
    remove(shp(s, sid=sid))
hdr = shp(s, sid=9)
place(hdr, 9.45, 2.05, 3.10)
set_text(hdr, "s and p reflectivity (a), the molecular-frame π* tensor through depth (b, c), density and tilt (d)")
place(shp(s, sid=19), 9.45, 3.55, 3.10, 3.40)
place(shp(s, sid=20), 9.62, 3.55, 2.78, 3.40)
set_text(shp(s, sid=20), "The optical response reorganizes through the film",
         "From the free surface (red) to the oxide (blue) the π* tensor changes continuously. What drives the reorganization is an open question.")
notes(s, """TIME 1.5 min

SOURCE PLACEHOLDER FIGURE. Manuscript fig4 (znpc_fig4, heights and constant cone angles free). Replace with the TDM-only refit. Dissertation Chapter 5 reports that in this fit the two lowest pi star resonances exchange oscillator strength between the free surface and the oxide while their sum is nearly conserved; recheck that statement against the refit before using it.

SCRIPT On the left is the fit to s and p reflectivity at the five energies, the dipole-refined model in black against the static NEXAFS tensor in dashed gray. Panels b and c are what the fit says about the molecule itself, the in-plane and out-of-plane components of the pi star tensor, colored from the free surface in red to the oxide in blue. Panel d is the density and the molecular tilt from Chapter 4. The tensor is not the same molecule at every depth. It changes continuously from one interface to the other, and the changes differ resonance by resonance, which a tilt alone cannot produce. We can see that reorganization, buried, through the full depth of the film. What drives it, packing, conformation, or the interface potentials, we cannot yet say.

TRANSITION How far can a few energies take this?""")

prs.save("/home/claude/work/stage2.pptx")
print("saved")
