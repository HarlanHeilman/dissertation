import sys; sys.path.insert(0, "/home/claude/work/figsrc")
from style import *
import numpy as np
from matplotlib.patches import FancyArrowPatch
# oblique projection of an octahedron (Al at origin)
def P(v):
    x, y, z = v
    return np.array([x + 0.42 * y * np.cos(np.radians(35)), z + 0.42 * y * np.sin(np.radians(35))])
V = {"+x": (1, 0, 0), "-x": (-1, 0, 0), "+y": (0, 1, 0), "-y": (0, -1, 0), "+z": (0, 0, 1), "-z": (0, 0, -1)}
EDGES = [(a, b) for a in V for b in V if a < b and np.dot(V[a], V[b]) == 0]
def draw(ax, O, N, pairs, title, sub):
    for a, b in EDGES:
        p, q = P(V[a]), P(V[b]); ax.plot([p[0], q[0]], [p[1], q[1]], color=SLATE, lw=0.6, alpha=0.45, zorder=1)
    for k in V:
        p = P(V[k]); ax.plot([0, p[0]], [0, p[1]], color=SLATE, lw=1.0, zorder=2)
    for o, n in pairs:  # bidentate quinolinolate bite between cis O and N
        p, q = P(V[o]), P(V[n]); mid = (p + q) / 2; out = mid / (np.linalg.norm(mid) + 1e-9)
        ax.add_patch(FancyArrowPatch(p, q, connectionstyle="arc3,rad=-0.45" if (p[0]*q[1]-p[1]*q[0]) > 0 else "arc3,rad=0.45",
                     arrowstyle="-", lw=5, color="#C9C1B8", zorder=0))
    ax.plot([0], [0], "o", ms=15, color="#8A8F94", zorder=4); ax.text(0, 0, "Al", ha="center", va="center", fontsize=9, color="white", zorder=5)
    for k in O:
        p = P(V[k]); ax.plot(*p, "o", ms=16, color=CRIMSON, zorder=6); ax.text(*p, "O", ha="center", va="center", fontsize=10, color="white", zorder=7)
    for k in N:
        p = P(V[k]); ax.plot(*p, "o", ms=16, color=BLUE, zorder=6); ax.text(*p, "N", ha="center", va="center", fontsize=10, color="white", zorder=7)
    ax.set_xlim(-1.55, 1.55); ax.set_ylim(-1.45, 1.55); ax.set_aspect("equal"); ax.axis("off")
    ax.text(0, -1.42, title, ha="center", va="top", fontsize=13, color=INK)
    ax.text(0, -1.78, sub, ha="center", va="top", fontsize=10.5, color=SLATE)
fig = plt.figure(figsize=(3.6, 2.35))
a1 = fig.add_axes([0.0, 0.22, 0.5, 0.78]); a2 = fig.add_axes([0.5, 0.22, 0.5, 0.78])
draw(a1, ["+x", "+y", "-x"], ["+z", "-z", "-y"], [("+y", "+z"), ("+x", "-y"), ("-x", "-z")], "mer", "O in one plane")
draw(a2, ["+x", "+y", "+z"], ["-x", "-y", "-z"], [("+x", "-y"), ("+y", "-z"), ("+z", "-x")], "fac", "O on one face")
fig.savefig("/home/claude/work/figs/alq3-mer-fac.png", dpi=300)
