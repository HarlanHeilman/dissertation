"""GIF 13. From a carbon core site to its final state, for four raw StoBe transition-potential transitions drawn at
random (znpc_states13.py, seed 2026, one per carbon site). Left, the ground-state molecule with the core-hole carbon lit
by the incoming photon. Right, the same molecule with the final-state orbital (signed p lobes of the final MO) and the
transition dipole at the core-hole atom. Bottom, every DFT stick between 283.5 and 300 eV coloured by site, the current
transition highlighted. Static words (panel titles, counts) are PowerPoint text on the slide."""
import math, pickle
import numpy as np
import pandas as pd
from style import *

SIZE = (1600, 800)
NS = 4
PER = 3.2
DUR = NS * PER
S = pickle.load(open("/home/claude/omgif/znpc_states13.pkl", "rb"))
ST = pd.read_csv("/home/claude/znpc_data/data/csv/znpc_sticks_tensor.csv")
ST = ST[ST.en.between(283.5, 300.0)]
SITE_COL = {1: "#2E6F82", 2: "#9DBBC6", 3: "#E2B4AE", 4: "#C2492D"}   # slide 8 bar colours, C1 to C4

ELEV = math.radians(34)
AZ = math.radians(95)
SC = 40.0
CEN = {"L": (385, 255), "R": (1215, 255)}
for _st in S:                       # each molden lists the core-hole carbon first, so geometry is per state
    _st["XYZ"] = _st["xyz"] - _st["xyz"][list(_st["Z"]).index(30)]
XYZ = S[0]["XYZ"]
ZN = S[0]["Z"]


def rot(p):
    c, s = math.cos(AZ), math.sin(AZ)
    x, y, z = p[..., 0], p[..., 1], p[..., 2]
    return np.stack([c * x - s * y, s * x + c * y, z], -1)


def proj(p, side):
    r = rot(np.asarray(p, float))
    x, y, z = r[..., 0], r[..., 1], r[..., 2]
    up = y * math.sin(ELEV) + z * math.cos(ELEV)
    depth = -y * math.cos(ELEV) + z * math.sin(ELEV)
    cx, cy = CEN[side]
    return cx + SC * x, cy - SC * up, depth


def _bonds():
    out = []
    for i in range(len(XYZ)):
        for j in range(i + 1, len(XYZ)):
            d = np.linalg.norm(XYZ[i] - XYZ[j])
            zi, zj = ZN[i], ZN[j]
            if 1 in (zi, zj):
                if d < 1.2:
                    out.append((i, j, "h"))
            elif 30 in (zi, zj):
                if d < 2.15:
                    out.append((i, j, "zn"))
            elif d < 1.6:
                out.append((i, j, "cc"))
    return out


for _st in S:
    XYZ, ZN = _st["XYZ"], _st["Z"]
    _st["BONDS"] = _bonds()
XYZ, ZN = S[0]["XYZ"], S[0]["Z"]
_, _, SD = proj(XYZ, "L")
DMIN, DMAX = SD.min(), SD.max()


def depth_alpha(d):
    return 0.62 + 0.38 * (d - DMIN) / (DMAX - DMIN)


def setc(ctx, c, a):
    if isinstance(c, str):
        src(ctx, c, a)
    else:
        ctx.set_source_rgba(c[0], c[1], c[2], a)


def molecule(side, exc, prims, lit=0.0, dim=1.0):
    X, Y, D = proj(XYZ, side)
    for i, j, kind in CUR["BONDS"]:
        d = 0.5 * (D[i] + D[j])

        def paint(ctx, i=i, j=j, kind=kind, d=d):
            col, w = {"cc": (DEEP, 4.2), "h": (SLATE, 2.6), "zn": (SLATE, 2.2)}[kind]
            src(ctx, col, depth_alpha(d) * dim)
            ctx.set_line_width(w)
            if kind == "zn":
                ctx.set_dash([4, 4])
            ctx.move_to(X[i], Y[i]); ctx.line_to(X[j], Y[j]); ctx.stroke(); ctx.set_dash([])
        prims.append((d - 0.02, paint))
    for i in range(len(XYZ)):
        def paint(ctx, i=i):
            al = depth_alpha(D[i]) * dim
            z = ZN[i]
            ctx.new_path()
            if z == 30:
                src(ctx, "#6F777B", al); ctx.arc(X[i], Y[i], 14, 0, 2 * math.pi); ctx.fill()
                text(ctx, X[i], Y[i] + 7, "Zn", 18, IVORY, al, "c")
                return
            r, fill, edge = {1: (4.5, IVORY, MUTED), 7: (6.5, ICE, NAVY)}.get(int(z), (5.5, IVORY, DEEP))
            if i == exc:
                r = 5.5 + 4.5 * lit
                fill = mix(IVORY, CLAY, lit)
                edge = mix(DEEP, RUST, lit)
            setc(ctx, fill, al); ctx.arc(X[i], Y[i], r, 0, 2 * math.pi); ctx.fill_preserve()
            setc(ctx, edge, al); ctx.set_line_width(2.0 if z != 1 else 1.4); ctx.stroke()
        prims.append((D[i], paint))
    return X, Y


def draw_lobe(c3, v3, size, sign, a, prims):
    cx, cy, cd = proj(c3, "R")
    tip = proj(c3 + v3, "R")
    dx, dy = tip[0] - cx, tip[1] - cy
    L = math.hypot(dx, dy)
    ang = math.atan2(dy, dx) if L > 1e-6 else 0.0
    smaj = max(0.27 * size, 0.52 * size * L / SC)
    smin = 0.27 * size

    def paint(ctx):
        ctx.save(); ctx.translate(cx, cy); ctx.rotate(ang); ctx.scale(smaj * SC, smin * SC)
        ctx.arc(0, 0, 1, 0, 2 * math.pi); ctx.restore()
        src(ctx, IVORY, 0.35 * a); ctx.fill_preserve()
        src(ctx, CRIMSON if sign > 0 else SKY, 0.62 * a); ctx.fill_preserve()
        src(ctx, CRIMSON if sign > 0 else BLUE, 0.85 * a); ctx.set_line_width(1.4); ctx.stroke()
    prims.append((cd + 0.01, paint))


def lobes(st, a, prims):
    lob = st["lobes"]; exc = st["exc"]
    mag = np.linalg.norm(lob, axis=1); m = mag.max()
    near = np.linalg.norm(XYZ - XYZ[exc], axis=1) < 1.6
    show = (mag > 0.42 * m) | (near & (mag > 0.08 * m))
    for i in np.where(show)[0]:
        w = max(mag[i] / m, 0.35 if near[i] else 0.0)
        v = lob[i] / mag[i]
        size = 0.45 + 0.65 * math.sqrt(w)
        off = 0.50 * size
        draw_lobe(XYZ[i] + v * off, v, size, +1, a * (0.45 + 0.55 * w), prims)
        draw_lobe(XYZ[i] - v * off, -v, size, -1, a * (0.45 + 0.55 * w), prims)


def double_arrow(ctx, b0, b1, col, a):
    ctx.set_source_rgba(col[0], col[1], col[2], a); ctx.set_line_width(4.5)
    ctx.move_to(b0[0], b0[1]); ctx.line_to(b1[0], b1[1]); ctx.stroke()
    for p, q in ((b1, b0), (b0, b1)):
        angh = math.atan2(p[1] - q[1], p[0] - q[0])
        ctx.save(); ctx.translate(p[0], p[1]); ctx.rotate(angh)
        ctx.move_to(4, 0); ctx.line_to(-16, -9); ctx.line_to(-12, 0); ctx.line_to(-16, 9); ctx.close_path()
        ctx.set_source_rgba(col[0], col[1], col[2], a); ctx.fill(); ctx.restore()


AX = Axes(150, 590, 1450, 720, (283.5, 300.0), (0, float(np.sqrt(ST.os.max())) * 1.08))


def frame(t):
    surf, ctx = new_frame(*SIZE)
    k = int(t // PER) % NS
    u = t - k * PER
    st = S[k]; exc = st["exc"]
    global XYZ, ZN, CUR
    XYZ, ZN, CUR = st["XYZ"], st["Z"], st
    fade = ramp(u, 0.0, 0.25) * (1 - ramp(u, PER - 0.3, PER - 0.02))
    lit = ramp(u, 0.55, 0.85) * (1 - ramp(u, PER - 0.3, PER - 0.02))
    la = ramp(u, 1.05, 1.55) * (1 - ramp(u, PER - 0.3, PER - 0.02))

    # left, ground state with the core-hole carbon
    prims = []
    XL, YL = molecule("L", exc, prims, lit=lit)
    for _, paint in sorted(prims, key=lambda p: p[0]):
        paint(ctx)
    ex, ey = XL[exc], YL[exc]
    pa = ramp(u, 0.05, 0.15) * (1 - ramp(u, 0.6, 0.72))
    if pa > 0.01:
        s0 = clamp((u - 0.05) / 0.6)
        ang = math.radians(-35)
        Lp = 300 * (1 - s0)
        wave_packet(ctx, ex - Lp * math.cos(ang), ey - Lp * math.sin(ang), ang, 40, 12, 12, 2 * math.pi * 3 * t, CLAY, pa)
    glow(ctx, ex, ey, 40, CLAY, 0.85 * lit)
    text(ctx, 385, 470, f"{st['site']} 1s core hole", 32, RUST, fade, "c")

    # transfer arrow between the panels
    ga = ramp(u, 0.75, 1.15) * (1 - ramp(u, PER - 0.3, PER - 0.02))
    x0, x1, ya = 735, 865, 255
    src(ctx, SLATE, 0.35)
    ctx.set_line_width(5); ctx.move_to(x0, ya); ctx.line_to(x1 - 12, ya); ctx.stroke()
    arrow_head(ctx, x1, ya, 0.0, 22, SLATE, 0.35)
    if ga > 0.01:
        src(ctx, CLAY, ga); ctx.set_line_width(5)
        ctx.move_to(x0, ya); ctx.line_to(x0 + (x1 - 12 - x0) * clamp((u - 0.75) / 0.4), ya); ctx.stroke()
        if u > 1.1:
            arrow_head(ctx, x1, ya, 0.0, 22, CLAY, ga)
    text(ctx, (x0 + x1) / 2, ya - 22, "$μ_{0i}$", 34, INK, 1.0, "c")

    # right, final state
    prims = []
    molecule("R", exc, prims, lit=0.0, dim=0.75)
    lobes(st, la, prims)
    for _, paint in sorted(prims, key=lambda p: p[0]):
        paint(ctx)
    th = st["theta"]
    col = mix(DEEP, NAVY, math.sin(math.radians(th)) ** 2)
    c0 = XYZ[exc]; mu = st["tdm"]
    grow = ramp(u, 1.3, 1.8) * (1 - ramp(u, PER - 0.3, PER - 0.02))
    if grow > 0.02:
        b0 = proj(c0 - 2.2 * grow * mu, "R"); b1 = proj(c0 + 2.2 * grow * mu, "R")
        double_arrow(ctx, b0, b1, col, grow)
    kind = "$π^{*}$" if th < 30 else "$σ^{*}$"
    text(ctx, 1215, 470, f"MO {st['mo']},  {st['en']:.1f} eV,  " + kind, 32, INK, la, "c")

    # bottom, every stick, the current one highlighted
    AX.frame(ctx, xticks=(284, 286, 288, 290, 292, 294, 296, 298, 300), xlabel=None, size=24)
    for en, os_, site in zip(ST.en, ST.os, ST.atomid):
        x = AX.X(en); y = AX.Y(math.sqrt(os_))
        src(ctx, SITE_COL[int(site)], 0.75); ctx.set_line_width(1.6)
        ctx.move_to(x, AX.y1); ctx.line_to(x, y); ctx.stroke()
    xs = AX.X(st["en"]); ys = AX.Y(math.sqrt(st["os"]))
    hl = ramp(u, 1.05, 1.4) * (1 - ramp(u, PER - 0.3, PER - 0.02))
    if hl > 0.01:
        src(ctx, CLAY, hl); ctx.set_line_width(5); ctx.move_to(xs, AX.y1); ctx.line_to(xs, min(ys, AX.y1 - 10)); ctx.stroke()
        glow(ctx, xs, min(ys, AX.y1 - 10), 22, CLAY, 0.8 * hl)
        ctx.new_path(); src(ctx, CLAY, hl); ctx.arc(xs, min(ys, AX.y1 - 10), 7, 0, 2 * math.pi); ctx.fill()
    return surf
