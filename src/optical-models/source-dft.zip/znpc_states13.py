"""States for GIF 13: four raw StoBe transition-potential transitions drawn at random (seed 2026), one per carbon
core site, from the aligned sticks with oscillator strength in the top quarter and energy 284 to 300 eV.
Lobes and dipoles come from the TP molden files exactly as for GIF 11 (znpc_states.py, znpc_tdm.py)."""
import math, pickle, numpy as np, pandas as pd
import molden_mo as M
from znpc_states import D, p_vectors, r0_amp
from znpc_tdm import tdm

ST = pd.read_csv("/home/claude/znpc_data/data/csv/znpc_sticks_tensor.csv")
rng = np.random.default_rng(2026)
pool = ST[(ST.os >= ST.os.quantile(0.75)) & ST.en.between(284.0, 300.0)]
picks = []
for site in (1, 2, 3, 4):
    sub = pool[pool.atomid == site]
    picks.append(sub.iloc[rng.integers(len(sub))])
out = []
for r in picks:
    site, mo = f"C{int(r.atomid)}", int(r.mo)
    atoms, shells, Cs = M.load(f"{D}/{site}/{site}tp.molden", {mo})
    xyz = np.array([a[2] for a in atoms]) / M.ANG
    Z = np.array([a[1] for a in atoms]); names = [a[0] for a in atoms]
    exc = int(np.where(Z == 6)[0][0])
    lob = p_vectors(atoms, shells, Cs[mo], r0_amp)
    mu = tdm(site, [mo])[mo]; u = mu / np.linalg.norm(mu)
    cen = xyz.mean(0); _, _, vt = np.linalg.svd(xyz - cen); nrm = vt[2] * np.sign(vt[2][2])
    th = math.degrees(math.acos(abs(u @ nrm)))
    print(site, "MO", mo, f"{r.en:.2f} eV", f"os {r.os:.4f}", "cluster", int(r.cluster), f"theta {th:.0f} (sticks {r.tdm_theta:.0f})", names[exc])
    out.append(dict(site=site, mo=mo, en=float(r.en), os=float(r.os), cluster=int(r.cluster), theta=th, xyz=xyz, Z=Z,
                    names=names, exc=exc, lobes=lob, tdm=u, normal=nrm))
pickle.dump(out, open("znpc_states13.pkl", "wb"))
