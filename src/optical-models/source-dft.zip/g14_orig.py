"""GIF 14. Clustering the ZnPc DFT transitions into an optical model (Murcia's overlap clustering, dft-learn).
  0.0 to 1.8 s   every DFT stick between 283.5 and 300 eV coloured by carbon site, broadened DFT spectrum
  1.8 to 3.0 s   rigid shift of the DFT energy scale by +0.45 eV (the seed shift of dissertation Fig. 2.6)
  3.0 to 4.2 s   sticks recoloured by cluster
  4.2 to 6.2 s   sticks collapse onto their cluster, one Gaussian per cluster (centre = strength-weighted mean,
                 width = seed width, area = summed strength)
  6.2 to 7.8 s   Gaussians move to the values refined against angle-resolved NEXAFS (cluster_gaussians.csv,
                 en_f, wid_f, area scaled by amp_f / amp_i); dipoles are held
Data: znpc_sticks_tensor.csv (aligned sticks, cluster labels), cluster_gaussians.csv (seed and refined)."""
import math
import numpy as np
import pandas as pd
from style import *

SIZE = (1600, 720)
DUR = 12.0
SHIFT = 0.45
ST = pd.read_csv("/home/claude/znpc_data/data/csv/znpc_sticks_tensor.csv")
CG = pd.read_csv("/home/claude/znpc_data/data/csv/cluster_gaussians.csv").set_index("cluster")
XL = (283.5, 300.5)
ST = ST[ST.en.between(XL[0] - 1, XL[1])]
SITE_COL = {1: "#2E6F82", 2: "#9DBBC6", 3: "#E2B4AE", 4: "#C2492D"}
CL = sorted(int(c) for c in ST.cluster.unique() if int(c) in CG.index)
G0 = {}
for c in CL:
    m = ST[ST.cluster == c]
    area = m.os.sum()
    G0[c] = dict(en=float((m.en * m.os).sum() / area) + SHIFT, wid=float(CG.loc[c, "wid_i"]), area=float(area))
G1 = {c: dict(en=float(CG.loc[c, "en_f"]), wid=float(CG.loc[c, "wid_f"]),
              area=G0[c]["area"] * float(CG.loc[c, "amp_f"] / CG.loc[c, "amp_i"])) for c in CL}
_k = sum(G0[c]["area"] for c in CL) / sum(G1[c]["area"] for c in CL)   # refined amplitudes are on the NEXAFS scale;
for c in CL:                                                           # keep their ratios, match the seed total
    G1[c]["area"] *= _k
STOPS = ["#2E7D8C", "#8A8F94", "#E07A6E"]


def ccol(c):
    t = CL.index(c) / max(len(CL) - 1, 1)
    return mix(STOPS[0], STOPS[1], t / 0.5) if t < 0.5 else mix(STOPS[1], STOPS[2], (t - 0.5) / 0.5)


EG = np.linspace(*XL, 1400)
# ionization edge: one erf step per carbon site at its refined IP (param_change.json), width 0.70 eV as the Alq3 model.
# Total jump set so jump/(pi* peak) of the drawn model equals that of the measured beta (exp_bets.csv, 320 vs 282 eV).
import json
from scipy.special import erf
IPS = dict(zip(("C1", "C2", "C3", "C4"), json.load(open("/home/claude/znpc_data/data/csv/param_change.json"))["global"]["IPs"]))
_b = pd.read_csv("/home/claude/znpc_data/data/optical/exp_bets.csv")
_e, _y = _b.Energy.values, _b["βiso"].values
_pre = np.interp(282.0, _e, _y)
JUMP_FRAC = (np.interp(320.0, _e, _y) - _pre) / (_y[(_e > 284) & (_e < 287)].max() - _pre)
STEP_W = 0.70


def step_curve(h):
    return sum(h / 4 * 0.5 * (1 + erf((EG - ip) / STEP_W)) for ip in IPS.values())


def gauss(en, wid, area):
    return area / (wid * math.sqrt(2 * math.pi)) * np.exp(-0.5 * ((EG - en) / wid) ** 2)


def envelope(shift):
    y = np.zeros_like(EG)
    for en, os_, w in zip(ST.en, ST.os, ST.wid):
        y += os_ / (w * math.sqrt(2 * math.pi)) * np.exp(-0.5 * ((EG - en - shift) / w) ** 2)
    return y


ENV0, ENV1 = envelope(0.0), envelope(SHIFT)
YMAX = float(max(ENV0.max(), max((gauss(**G1[c]).max() for c in CL)), max((gauss(**G0[c]).max() for c in CL)))) * 1.1
_pk0 = max(gauss(**G0[c]).max() for c in CL[:3])
_tot = [sum(gauss(**G[c]) for c in CL) + step_curve(JUMP_FRAC * _pk0) for G in (G0, G1)]
YMAX = max(YMAX, max(float(x.max()) for x in _tot) * 1.08)
SMAX = float(ST.os.max())
AX = Axes(120, 40, 1560, 600, XL, (0, YMAX))


def setc(ctx, c, a):
    if isinstance(c, str):
        src(ctx, c, a)
    else:
        ctx.set_source_rgba(c[0], c[1], c[2], a)


def frame(t):
    surf, ctx = new_frame(*SIZE)
    src(ctx, "#FCFFFB"); ctx.paint()          # card fill on slide 9
    sh = SHIFT * smooth(ramp(t, 1.8, 3.0))
    rec = ramp(t, 3.0, 4.2)
    col = ramp(t, 4.2, 6.2)
    ref = smooth(ramp(t, 7.6, 9.2))
    stp = smooth(ramp(t, 6.3, 7.3))
    AX.frame(ctx, xticks=(284, 286, 288, 290, 292, 294, 296, 298, 300), size=26)

    # broadened DFT reference
    env = ENV0 + (ENV1 - ENV0) * (sh / SHIFT)
    pts = AX.pts(EG, env)
    polyline(ctx, pts, SLATE, 2.4, 0.85 - 0.45 * col, dash=[10, 6] if col > 0.05 else None)

    # sticks: site colour, then cluster colour, then sliding into their cluster centre
    hs = 0.45 * YMAX / math.sqrt(SMAX)
    sa = 0.8 * (1 - smooth(ramp(t, 5.0, 6.2)))
    if sa > 0.01:
        for en, os_, site, c in zip(ST.en, ST.os, ST.atomid, ST.cluster):
            c = int(c)
            if c not in G0:
                continue
            x0 = en + sh
            x = x0 + (G0[c]["en"] - x0) * smooth(col)
            if not XL[0] <= x <= XL[1]:
                continue
            cc = mix(SITE_COL[int(site)], "#000000", 0.0) if rec < 1 else ccol(c)
            if 0 < rec < 1:
                a_, b_ = hexrgb(SITE_COL[int(site)]), ccol(c)
                cc = tuple(a_[k] + (b_[k] - a_[k]) * rec for k in range(3))
            setc(ctx, cc, sa)
            ctx.set_line_width(1.8)
            X = AX.X(x)
            ctx.move_to(X, AX.y1); ctx.line_to(X, AX.y1 - hs * math.sqrt(os_) * (AX.y1 - AX.y0) / YMAX); ctx.stroke()

    # cluster Gaussians, seed then refined
    ga = smooth(ramp(t, 4.6, 6.2))
    if ga > 0.01:
        total = np.zeros_like(EG)
        peak0 = max(gauss(**G0[c]).max() for c in CL[:3])
        for c in CL:
            p = {k: G0[c][k] + (G1[c][k] - G0[c][k]) * ref for k in ("en", "wid", "area")}
            y = gauss(**p) * ga
            total += y
            cpts = AX.pts(EG, y)
            cc = ccol(c)
            ctx.new_path()
            ctx.move_to(cpts[0][0], AX.y1)
            for px, py in cpts:
                ctx.line_to(px, py)
            ctx.line_to(cpts[-1][0], AX.y1); ctx.close_path()
            ctx.set_source_rgba(cc[0], cc[1], cc[2], 0.42 * ga); ctx.fill_preserve()
            ctx.set_source_rgba(cc[0], cc[1], cc[2], 0.9 * ga); ctx.set_line_width(1.6); ctx.stroke()
        if stp > 0.01:
            st = step_curve(JUMP_FRAC * peak0) * stp
            spts = AX.pts(EG, st)
            ctx.new_path(); ctx.move_to(spts[0][0], AX.y1)
            for px, py in spts:
                ctx.line_to(px, py)
            ctx.line_to(spts[-1][0], AX.y1); ctx.close_path()
            c_ = hexrgb(TAUPE); ctx.set_source_rgba(c_[0], c_[1], c_[2], 0.45 * stp); ctx.fill()
            polyline(ctx, spts, RUST, 2.4, stp)
            for nm, ip in IPS.items():
                X = AX.X(ip)
                src(ctx, RUST, 0.8 * stp); ctx.set_line_width(1.6); ctx.set_dash([4, 4])
                ctx.move_to(X, AX.y1); ctx.line_to(X, AX.Y(JUMP_FRAC * peak0 * 1.15)); ctx.stroke(); ctx.set_dash([])
            total = total + st
        polyline(ctx, AX.pts(EG, total), INK, 3.0, ga)

    # dynamic captions
    a1 = ramp(t, 1.8, 2.1) * (1 - ramp(t, 3.4, 3.8))
    if a1 > 0.01:
        text(ctx, AX.X(286.2), 110, "DFT energies  +0.45 eV", 30, RUST, a1, "l")
    a2 = ramp(t, 4.4, 4.8) * (1 - ramp(t, 6.0, 6.3))
    if a2 > 0.01:
        text(ctx, AX.X(286.2), 110, "one Gaussian per cluster", 30, INK, a2, "l")
    a25 = ramp(t, 6.3, 6.7) * (1 - ramp(t, 7.4, 7.7))
    if a25 > 0.01:
        text(ctx, AX.X(286.2), 110, "+ ionization edge, one step per carbon site", 30, RUST, a25, "l")
    a3 = ramp(t, 7.7, 8.1) * (1 - ramp(t, DUR - 0.35, DUR - 0.05))
    if a3 > 0.01:
        text(ctx, AX.X(286.2), 110, "refined against angle-resolved NEXAFS, dipoles held", 30, NAVY, a3, "l")
    return surf
