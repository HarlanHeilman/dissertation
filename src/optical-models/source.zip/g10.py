"""GIF 10 (from GIF 9). Steps on the Biggs-Lighthill carbon fit, rho = 1 g cm^-3, delta Z*-anchored (step_bl.npz).
GIF 9 notes follow. erf against arctan ionization step, equal kernel FWHM (1.17 eV), data from step2.npz.
Original GIF 8 notes follow. The ionization step of the model, alone. beta = 0.5[1 + erf((E - IP)/0.7)] (E/IP)^-2.6, normalised to a
unit jump, with delta from a numerical Kramers-Kronig transform carrying the tail to 30 keV (precomputed in
/tmp/step.npz by the same subtraction-method KK used in spectra.py). Single column, 800 x 1200, matching g7.
In the complex plane the step draws an open arc: delta dips logarithmically at the edge, beta never returns
inside the window, and the curve closes on n = 1 only through the far tail."""
import math
import numpy as np
from style import *
import layout as L

DUR = L.DUR
SIZE = L.SIZE
_d = np.load("/home/claude/omgif/step_bl.npz")
EG = _d["E"]
PRE, POST = _d["pre"], _d["post"]
STEPS = [("arctan step", "lifetime damping", INK, _d["atan_B"], _d["atan_D"], _d["atan_Bt"], _d["atan_Dt"]),
         ("erf step", "inhomogeneous broadening", CRIMSON, _d["erf_B"], _d["erf_D"], _d["erf_Bt"], _d["erf_Dt"])]
IP = 290.3
ELO, EHI = float(EG[0]), float(EG[-1])

AX = Axes(*L.AX_BOX, (ELO, EHI), (-1.3, 2.25))
_XL = (-1.55, 1.25)
_YT, UNIT = L.cp_ylim(_XL)
CP = Axes(*L.CP_BOX, _XL, (0, _YT))
T0, T1 = L.T0, L.T1
FADE = L.FADE


def _g(E, e0, s):
    return np.exp(-0.5 * ((E - e0) / s) ** 2)


DWELL = 1 + 5 * _g(EG, IP, 1.2)
CUM = np.concatenate([[0], np.cumsum(0.5 * (DWELL[1:] + DWELL[:-1]) * np.diff(EG))])
CUM /= CUM[-1]


def energy(t):
    u = clamp((t - T0) / (T1 - T0))
    u = 0.5 - 0.5 * math.cos(math.pi * u)
    return float(np.interp(u, CUM, EG))


def at(arr, E):
    return float(np.interp(E, EG, arr))


def frame(t):
    surf, ctx = new_frame(*SIZE)
    E = energy(t)
    fd = 1 - ramp(t, *FADE)
    ca = fd * ramp(t, 0.0, 0.35)
    la = fd * ramp(t, T1 + 0.1, T1 + 0.6)
    m = EG <= E

    for k, (name, sub, col, B, D, BT, DT) in enumerate(STEPS):
        x = L.LEG_X[k]
        text(ctx, x, L.LEG_Y[0], name, 36, col)
        text(ctx, x, L.LEG_Y[1], sub, 28, SLATE, 0.95)

    # spectrum
    AX.frame(ctx, xticks=(280, 290, 300, 310, 320), xlabel="Photon energy (eV)", size=32, zero=0.0)
    src(ctx, SLATE, 0.6)
    ctx.set_line_width(2)
    ctx.set_dash([7, 6])
    ctx.move_to(AX.X(IP), AX.y0)
    ctx.line_to(AX.X(IP), AX.y1)
    ctx.stroke()
    ctx.set_dash([])
    text(ctx, AX.X(IP), AX.y0 - 10, "IP", 28, SLATE, 1.0, "c")
    # regions
    src(ctx, SLATE, 0.06)
    ctx.rectangle(AX.x0, AX.y0, AX.X(IP) - AX.x0, AX.y1 - AX.y0)
    ctx.fill()
    text(ctx, (AX.x0 + AX.X(IP)) / 2, AX.y0 + 30, "pre edge", 28, SLATE, 0.95, "c")
    text(ctx, (AX.X(IP) + AX.x1) / 2, AX.y0 + 30, "post edge", 28, SLATE, 0.95, "c")
    for name, sub, col, B, D, BT, DT in STEPS:
        if m.sum() > 1:
            pb = AX.pts(EG[m], B[m])
            fill_under(ctx, pb, AX.Y(0), col, 0.08 * fd)
            polyline(ctx, pb, col, 5.0, fd)
            polyline(ctx, AX.pts(EG[m], D[m]), col, 3.4, 0.9 * fd, dash=[10, 7])
    B0, D0 = STEPS[1][3], STEPS[1][4]
    text(ctx, AX.X(293.6), AX.Y(1.98), "$β$", 40, INK, la)
    text(ctx, AX.X(308), AX.Y(at(D0, 308)) + 40, "$δ$", 40, INK, la)
    text(ctx, AX.X(280.6), AX.Y(1.25), "arctan tail", 28, INK, la)
    text(ctx, AX.X(291.6), AX.Y(-0.95), "log dip at the edge", 28, SLATE, la)
    cx = AX.X(E)
    src(ctx, CLAY, 0.85 * ca)
    ctx.set_line_width(2.4)
    ctx.set_dash([6, 6])
    ctx.move_to(cx, AX.y0)
    ctx.line_to(cx, AX.y1)
    ctx.stroke()
    ctx.set_dash([])
    for name, sub, col, B, D, BT, DT in STEPS:
        for arr in (B, D):
            ctx.new_path()
            src(ctx, col, ca)
            ctx.arc(cx, AX.Y(at(arr, E)), 6.5, 0, 2 * math.pi)
            ctx.fill()

    # complex plane
    x0 = CP.X(0.0)
    src(ctx, SLATE, 0.9)
    ctx.set_line_width(3)
    ctx.move_to(CP.x0, CP.y1)
    ctx.line_to(CP.x1, CP.y1)
    ctx.stroke()
    ctx.move_to(x0, CP.y1)
    ctx.line_to(x0, CP.y0)
    ctx.stroke()
    arrow_head(ctx, CP.x1 + 4, CP.y1, 0, 16, SLATE, 0.9)
    arrow_head(ctx, x0, CP.y0 - 4, -math.pi / 2, 16, SLATE, 0.9)
    text(ctx, CP.x1 + 10, CP.y1 + 46, "Re $n$ − 1", 32, SLATE, 1.0, "r")
    text(ctx, x0 + 16, CP.y0 + 14, "Im $n$", 32, SLATE, 1.0, "l")
    for name, sub, col, B, D, BT, DT in STEPS[::-1]:
        if m.sum() > 1:
            polyline(ctx, CP.pts(-D[m], B[m]), col, 4.6, fd)
    for name, sub, col, B, D, BT, DT in STEPS[::-1]:
        px, py = CP.X(-at(D, E)), CP.Y(at(B, E))
        glow(ctx, px, py, 22, col, 0.35 * ca)
        ctx.new_path()
        src(ctx, col, ca)
        ctx.arc(px, py, 9, 0, 2 * math.pi)
        ctx.fill()
    B0, D0 = STEPS[1][3], STEPS[1][4]
    sx, sy = CP.X(-D0[0]), CP.Y(B0[0])
    exx, eyy = CP.X(-D0[-1]), CP.Y(B0[-1])
    text(ctx, sx - 14, sy + 8, f"{ELO:.0f} eV", 26, SLATE, la, "r")
    text(ctx, exx - 14, eyy - 18, f"{EHI:.0f} eV", 26, SLATE, la, "r")
    text(ctx, CP.x1, CP.y0 + 20, "deeper $δ$ dip", 28, CRIMSON, la, "r")
    text(ctx, CP.X(-0.62), CP.Y(0.95), "softer turn", 28, INK, la, "c")
    return surf
