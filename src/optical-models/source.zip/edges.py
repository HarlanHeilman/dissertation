"""Static core-level edge diagram: atomic levels, the edge each one opens, and the sawtooth
absorption that results. Photon energy runs downward, matching binding energy."""
import math
import cairo
from style import *

TOP = 92          # vacuum level / continuum threshold
# (label, y, edge label, colour)
LEVELS = [
    ("3d_{5/2}", 150, None, BLUE), ("3d_{3/2}", 164, "M_{4,5}", BLUE),
    ("3p_{3/2}", 232, None, BLUE), ("3p_{1/2}", 250, "M_{2,3}", BLUE),
    ("3s", 300, "M_{1}", BLUE),
    ("2p_{3/2}", 418, "L_{3}", CLAY), ("2p_{1/2}", 464, "L_{2}", CLAY),
    ("2s", 560, "L_{1}", CLAY),
    ("1s", 724, "K", CRIMSON),
]
LX0, LX1 = 950, 1050          # level ticks
SAW_X0 = 120                   # absorption axis origin
ARROW_X = {"K": 560, "L_{1}": 620, "L_{2}": 660, "L_{3}": 700, "M_{1}": 760, "M_{2,3}": 800, "M_{4,5}": 840}


def mu_of_y(y):
    """Absorption at photon energy mapped to y (larger y = higher energy)."""
    s = 0.0
    for lab, yl, edge, _ in LEVELS:
        if y >= yl:
            w = {"K": 1.25, "L_{1}": 0.8, "L_{2}": 0.7, "L_{3}": 1.0}.get(edge, 0.5)
            s += w * ((y - TOP + 40) / (yl - TOP + 40)) ** -2.6
    return s


def draw(ctx, W_, H_):
    src(ctx, BG)
    ctx.paint()
    ctx.set_line_cap(cairo.LINE_CAP_ROUND)
    ctx.set_line_join(cairo.LINE_JOIN_ROUND)
    # continuum band above the vacuum level
    g = cairo.LinearGradient(0, TOP, 0, 24)
    c = hexrgb(TAUPE)
    g.add_color_stop_rgba(0, c[0], c[1], c[2], 0.12)
    g.add_color_stop_rgba(1, c[0], c[1], c[2], 0.45)
    ctx.set_source(g)
    ctx.rectangle(480, 24, LX1 - 480, TOP - 24)
    ctx.fill()
    src(ctx, SLATE, 0.8)
    ctx.set_line_width(2.2)
    ctx.set_dash([8, 6])
    ctx.move_to(480, TOP)
    ctx.line_to(LX1, TOP)
    ctx.stroke()
    ctx.set_dash([])
    text(ctx, LX1 + 14, TOP + 11, "vacuum", 30, SLATE)
    text(ctx, LX1 - 6, 64, "continuum", 30, SLATE, 1.0, "r")

    # axes: absorption to the right, photon energy downward
    arrow(ctx, SAW_X0, TOP - 40, 470, TOP - 40, INK, 3.0, 18)
    text(ctx, 295, TOP - 58, "Absorption", 32, INK, 1.0, "c")
    arrow(ctx, SAW_X0, TOP - 40, SAW_X0, 785, INK, 3.0, 18)
    text(ctx, SAW_X0 - 22, 470, "Photon energy", 32, INK, 1.0, "c", rotate=-math.pi / 2)

    # sawtooth absorption
    ys = [TOP + 4 + i * 0.5 for i in range(int((775 - TOP) / 0.5))]
    vals = [mu_of_y(y) for y in ys]
    vmax = max(vals)
    pts = [(SAW_X0 + 18 + 300 * v / vmax, y) for v, y in zip(vals, ys)]
    src(ctx, CRIMSON, 0.10)
    ctx.move_to(SAW_X0, pts[0][1])
    for p in pts:
        ctx.line_to(*p)
    ctx.line_to(SAW_X0, pts[-1][1])
    ctx.close_path()
    ctx.fill()
    polyline(ctx, pts, CRIMSON, 4.5)

    # levels, guides, edges
    for lab, yl, edge, col in LEVELS:
        x_saw = SAW_X0 + 18 + 300 * mu_of_y(yl + 0.6) / vmax
        src(ctx, MUTED, 0.9)
        ctx.set_line_width(1.6)
        ctx.set_dash([5, 6])
        ctx.move_to(x_saw + 6, yl)
        ctx.line_to(LX0 - 8, yl)
        ctx.stroke()
        ctx.set_dash([])
        src(ctx, INK)
        ctx.set_line_width(5)
        ctx.move_to(LX0, yl)
        ctx.line_to(LX1, yl)
        ctx.stroke()
        if lab[:2] not in ("3d", "3p"):
            text(ctx, LX1 + 14, yl + 11, lab, 30, INK)
        if edge:
            x = ARROW_X[edge]
            arrow(ctx, x, yl, x, TOP - 4, col, 4.0, 18)
            if edge in ("K", "L_{1}", "M_{1}"):
                text(ctx, x + 14, yl - 16, f"{edge} edge" if edge == "K" else edge, 32, col)
    # grouped labels for close pairs
    text(ctx, ARROW_X["L_{2}"] - 10, 418 - 16, "L_{2}", 32, CLAY, 1.0, "r")
    text(ctx, ARROW_X["L_{3}"] + 12, 418 - 16, "L_{3}", 32, CLAY)
    text(ctx, ARROW_X["M_{2,3}"] + 12, 232 - 14, "M_{2,3}", 32, BLUE)
    text(ctx, ARROW_X["M_{4,5}"] + 12, 150 - 14, "M_{4,5}", 32, BLUE)
    # the soft X-ray edges this work uses
    text(ctx, LX1 + 14, 157 + 11, "3d", 30, INK)
    text(ctx, LX1 + 14, 241 + 11, "3p", 30, INK)
    text(ctx, ARROW_X["K"] + 14, 772, "C, N, O at 284, 410, 543 eV", 28, CRIMSON, 0.9)


if __name__ == "__main__":
    import sys
    out = sys.argv[1]
    s = cairo.ImageSurface(cairo.FORMAT_RGB24, 2 * W, 2 * H)
    c = cairo.Context(s)
    c.scale(2, 2)
    draw(c, W, H)
    s.write_to_png(out + ".png")
    sv = cairo.SVGSurface(out + ".svg", W, H)
    c = cairo.Context(sv)
    draw(c, W, H)
    sv.finish()
    print("ok")
