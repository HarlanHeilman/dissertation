"""erf and arctan ionization steps on the Biggs-Lighthill carbon photoabsorption fit.
sigma(E) = sum_k A_k E^-k (E in keV, cm^2/g) on each interval (Biggs and Lighthill, SC-RR-870070, as shipped in
kkcalc2's asf_database/db_data/original_biggs_file.dat). The atomic K jump at 0.284 keV is replaced by a step centred
at the molecular IP that bridges the pre-edge and post-edge power-law segments:
    beta(E) = beta_pre(E) + S(E) J(E),  J = beta_post - beta_pre above the IP and J(IP) below it,  S = erf or arctan.
beta = mu_m rho lambda / (4 pi), carbon at rho = 1 g cm^-3; delta from a full numerical KK transform."""
import numpy as np
from scipy.special import erf

BL_C = [  # (E_lo keV, E_hi keV, A1, A2, A3, A4)
    (0.0100, 0.0457, 5.704e3, 0.0, 0.0, 0.0),
    (0.0457, 0.284, -3.935e2, 3.219e2, -6.549e0, 2.086e-1),
    (0.284, 0.8, -9.022e2, 1.760e3, 1.549e3, -2.280e2),
    (0.8, 4.0, -7.363e0, -1.537e1, 2.672e3, -4.482e2),
    (4.0, 20.0, 1.640e0, -9.428e1, 2.872e3, -5.583e2),
    (20.0, 100.0, -3.742e-3, -1.232e0, 9.489e2, 1.406e4),
]
IP = 290.3
SIG = 0.7 / np.sqrt(2)
FWHM = 2 * np.sqrt(2 * np.log(2)) * SIG
HC = 12.39842e-8        # keV cm


def poly(row, Ek):
    _, _, a1, a2, a3, a4 = row
    return a1 / Ek + a2 / Ek ** 2 + a3 / Ek ** 3 + a4 / Ek ** 4


def beta_from_mu(mu, Ek):
    return mu * 1.0 * (HC / Ek) / (4 * np.pi) * 1e3      # in units of 1e-3


def beta_seg(i, E_eV):
    Ek = np.asarray(E_eV, float) / 1000
    return beta_from_mu(poly(BL_C[i], Ek), Ek)


def beta_bl(E_eV, step):
    """Full-range beta with the K edge replaced by the chosen step at the IP."""
    E = np.asarray(E_eV, float)
    Ek = E / 1000
    out = np.zeros_like(E)
    for i, row in enumerate(BL_C):
        if i in (1, 2):
            continue
        m = (Ek >= row[0]) & (Ek < row[1])
        out[m] = beta_from_mu(poly(row, Ek[m]), Ek[m])
    edge = (Ek >= BL_C[1][0]) & (Ek < BL_C[2][1])
    Ee = E[edge]
    pre = beta_seg(1, Ee)
    jump = np.where(Ee >= IP, beta_seg(2, np.maximum(Ee, IP)) - beta_seg(1, np.maximum(Ee, IP)),
                    float(beta_seg(2, IP) - beta_seg(1, IP)))     # J(E) above the IP, J(IP) below it
    if step == "erf":
        S = 0.5 * (1 + erf((Ee - IP) / 0.7))
    else:
        S = 0.5 + np.arctan(2 * (Ee - IP) / FWHM) / np.pi
    out[edge] = pre + S * jump
    return out


g = np.unique(np.concatenate([np.logspace(1, 5, 160000), np.linspace(270, 340, 40000), np.linspace(288, 293, 10000)]))


def kk(step, Ev):
    bg = beta_bl(g, step); fg = g * bg; a, b = g[0], g[-1]; out = []
    for e in Ev:
        fe = e * float(beta_bl(np.array([e]), step)[0]); d = e * e - g * g; m = np.abs(d) > 1e-9
        it = np.zeros_like(g); it[m] = (fg[m] - fe) / d[m]
        sing = (1 / (2 * e)) * np.log(((e + b) * (e - a)) / ((b - e) * (e + a)))
        out.append((2 / np.pi) * (np.trapezoid(it, g) + fe * sing))
    return np.array(out)


K = 2.8179403e-13 * (1.2398420e-4) ** 2 * (6.02214e23 / 12.011) / (2 * np.pi) * 1e3   # beta*E^2 per f2, 1e-3 units
ZSTAR = 6 - (6 / 82.5) ** 2.37


def zstar_correction(step):
    """kkcalc/Henke anchoring: f1 -> Z* at high energy. Adds the oscillator strength the tabulated range misses."""
    bg = beta_bl(g, step)
    f1_inf = (2 / np.pi) * np.trapezoid(bg * g, g) / K
    return ZSTAR - f1_inf


if __name__ == "__main__":
    E = np.linspace(280, 320, 801)
    Et = np.logspace(np.log10(320), np.log10(8e4), 160)
    out = dict(E=E, Et=Et, pre=beta_seg(1, E), post=beta_seg(2, E))
    for s in ("erf", "atan"):
        miss = zstar_correction(s)
        print(s, "missing electrons", round(miss, 3))
        out[s + "_B"] = beta_bl(E, s); out[s + "_D"] = kk(s, E) + K * miss / E ** 2
        out[s + "_Bt"] = beta_bl(Et, s); out[s + "_Dt"] = kk(s, Et) + K * miss / Et ** 2
    np.savez("step_bl.npz", **out)
    for s in ("erf", "atan"):
        print(s, [(e, round(float(np.interp(e, E, out[s + "_B"])), 4), round(float(np.interp(e, E, out[s + "_D"])), 3))
                  for e in (280, 289, 290.3, 292, 300, 320)])
    for e, f1h in ((320, 3.87969), (300, 2.71286)):
        print("Henke delta at", e, round(K * f1h / e ** 2, 3))
    print("tail end", out["erf_Bt"][-1], out["erf_Dt"][-1], "min tail delta", out["erf_Dt"].min(), out["erf_Dt"].max())
