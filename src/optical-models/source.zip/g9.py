"""GIF 9 (from GIF 8). erf against arctan ionization step, equal kernel FWHM (1.17 eV), data from step2.npz.
Original GIF 8 notes follow. The ionization step of the model, alone. beta = 0.5[1 + erf((E - IP)/0.7)] (E/IP)^-2.6, normalised to a
unit jump, with delta from a numerical Kramers-Kronig transform carrying the tail to 30 keV (precomputed in
/tmp/step.npz by the same subtraction-method KK used in spectra.py). Single column, 800 x 1200, matching g7.
In the complex plane the step draws an open arc: delta dips logarithmically at the edge, beta never returns
inside the window, and the curve closes on n = 1 only through the far tail."""
import math
import numpy as np
from style import *

DUR = 9.0
SIZE = (800, 1200)
_d = np.load("/home/claude/omgif/step2.npz")
EG = _d["E"]
STEPS = [("erf step", "integral of a Gaussian", CRIMSON, _d["erf_B"], _d["erf_D"], _d["erf_Bt"], _d["erf_Dt"]),
         ("arctan step", "integral of a Lorentzian", INK, _d["atan_B"], _d["atan_D"], _d["atan_Bt"], _d["atan_Dt"])]
IP = 290.3
ELO, EHI = float(EG[0]), float(EG[-1])

AX = Axes(120, 165, 760, 470, (ELO, EHI), (-2.15, 1.25))
CP = Axes(130, 735, 730, 1047, (-0.25, 2.15), (0, 1.25))     # 600/2.4 = 250 px/unit; 312/1.25 = 250
T0, T1 = 0.4, 6.0
FADE = (8.2, 8.9)


def _g(E, e0, s):
    return np.exp(-0.5 * ((E - e0) / s) ** 2)


DWELL = 1 + 5 * _g(EG, IP, 1.2)
CUM = np.concatenate([[0], np.cumsum(0.5 * (DWELL[1:] + DWELL[:-1]) * np.diff(EG))])
CUM /= CUM[-1]


def energy(t):
    u = clamp((t - T0) / (T1 - T0))
    u = 0.5 - 0.5 * math.cos(math.pi * u)
    return float(np.interp(u, CUM, EG))


def at(arr, E):
    return float(np.interp(E, EG, arr))


def frame(t):
    surf, ctx = new_frame(*SIZE)
    E = energy(t)
    fd = 1 - ramp(t, *FADE)
    ca = fd * ramp(t, 0.0, 0.35)
    la = fd * ramp(t, T1 + 0.1, T1 + 0.6)
    m = EG <= E

    for k, (name, sub, col, B, D, BT, DT) in enumerate(STEPS):
        x = 60 + k * 370
        text(ctx, x, 64, name, 36, col)
        text(ctx, x, 102, sub, 28, SLATE, 0.95)

    # spectrum
    AX.frame(ctx, xticks=(280, 290, 300, 310, 320), xlabel="Photon energy (eV)", size=32, zero=0.0)
    src(ctx, SLATE, 0.6)
    ctx.set_line_width(2)
    ctx.set_dash([7, 6])
    ctx.move_to(AX.X(IP), AX.y0)
    ctx.line_to(AX.X(IP), AX.y1)
    ctx.stroke()
    ctx.set_dash([])
    text(ctx, AX.X(IP) - 10, AX.y0 + 26, "IP", 28, SLATE, 0.9, "r")
    for name, sub, col, B, D, BT, DT in STEPS:
        if m.sum() > 1:
            pb = AX.pts(EG[m], B[m])
            fill_under(ctx, pb, AX.Y(0), col, 0.08 * fd)
            polyline(ctx, pb, col, 5.0, fd)
            polyline(ctx, AX.pts(EG[m], D[m]), col, 3.4, 0.9 * fd, dash=[10, 7])
    B0, D0 = STEPS[0][3], STEPS[0][4]
    text(ctx, AX.X(303), AX.Y(at(B0, 303)) - 18, "$β$", 40, INK, la)
    text(ctx, AX.X(303), AX.Y(at(D0, 303)) + 44, "$δ$", 40, INK, la)
    text(ctx, AX.X(280.6), AX.Y(0.30), "arctan tail", 26, INK, la)
    text(ctx, AX.X(291.4), AX.Y(-1.85) + 10, "log dip at the edge", 26, SLATE, la)
    cx = AX.X(E)
    src(ctx, CLAY, 0.85 * ca)
    ctx.set_line_width(2.4)
    ctx.set_dash([6, 6])
    ctx.move_to(cx, AX.y0)
    ctx.line_to(cx, AX.y1)
    ctx.stroke()
    ctx.set_dash([])
    for name, sub, col, B, D, BT, DT in STEPS:
        for arr in (B, D):
            ctx.new_path()
            src(ctx, col, ca)
            ctx.arc(cx, AX.Y(at(arr, E)), 6.5, 0, 2 * math.pi)
            ctx.fill()

    # complex plane
    x0 = CP.X(0.0)
    src(ctx, SLATE, 0.9)
    ctx.set_line_width(3)
    ctx.move_to(CP.x0, CP.y1)
    ctx.line_to(CP.x1, CP.y1)
    ctx.stroke()
    ctx.move_to(x0, CP.y1)
    ctx.line_to(x0, CP.y0)
    ctx.stroke()
    arrow_head(ctx, CP.x1 + 4, CP.y1, 0, 16, SLATE, 0.9)
    arrow_head(ctx, x0, CP.y0 - 4, -math.pi / 2, 16, SLATE, 0.9)
    text(ctx, CP.x1 + 10, CP.y1 + 46, "Re $n$ − 1", 32, SLATE, 1.0, "r")
    text(ctx, x0 + 16, CP.y0 + 14, "Im $n$", 32, SLATE, 1.0, "l")
    for name, sub, col, B, D, BT, DT in STEPS[::-1]:
        if la > 0.01:
            ctx.new_path()
            src(ctx, col, 0.5 * la)
            ctx.set_line_width(2.2)
            ctx.set_dash([4, 7])
            pts = CP.pts(-DT, BT)
            ctx.move_to(*pts[0])
            for p in pts[1:]:
                ctx.line_to(*p)
            ctx.stroke()
            ctx.set_dash([])
        if m.sum() > 1:
            polyline(ctx, CP.pts(-D[m], B[m]), col, 4.6, fd)
    for name, sub, col, B, D, BT, DT in STEPS[::-1]:
        px, py = CP.X(-at(D, E)), CP.Y(at(B, E))
        glow(ctx, px, py, 22, col, 0.35 * ca)
        ctx.new_path()
        src(ctx, col, ca)
        ctx.arc(px, py, 9, 0, 2 * math.pi)
        ctx.fill()
    B0, D0 = STEPS[0][3], STEPS[0][4]
    sx, sy = CP.X(-D0[0]), CP.Y(B0[0])
    exx, eyy = CP.X(-D0[-1]), CP.Y(B0[-1])
    text(ctx, sx - 8, sy - 18, f"{ELO:.0f} eV", 26, SLATE, la, "r")
    text(ctx, exx - 14, eyy - 18, f"{EHI:.0f} eV", 26, SLATE, la, "r")
    text(ctx, CP.X(1.62), CP.Y(1.10), "deeper $δ$ dip", 28, CRIMSON, la, "c")
    text(ctx, CP.X(1.0), CP.Y(0.42), "softer turn", 28, INK, la, "c")
    text(ctx, CP.x0, CP.y1 + 46, "dashed, 320 eV to 25 keV, closing on $n$ = 1", 26, SLATE, la, "l")
    return surf
