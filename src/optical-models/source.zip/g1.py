"""GIF 1. Core-level resonances. A swept X-ray beam crosses C, N and O atoms; each atom
absorbs (1s photoelectron) only once the photon energy passes its own 1s binding energy,
and the absorption spectrum builds element-specific edges."""
import math
import numpy as np
from scipy.special import erf
from style import *

DUR = 8.0
EDGES = [("C", 284.2, 4, 1.00), ("N", 409.9, 5, 0.80), ("O", 543.1, 6, 0.72)]
ELO, EHI = 240.0, 600.0
AX = Axes(110, 440, 1150, 660, (ELO, EHI), (0, 1))
BEAM_Y = 238
V, SP, SPAN, X_START = 175.0, 200.0, 1400.0, -120.0


def mu(E):
    E = np.asarray(E, float)
    out = 0.16 * (E / ELO) ** -2.4
    for _, ez, _, j in EDGES:
        out = out + j * (E / ez) ** -2.6 * 0.5 * (1 + erf((E - ez) / 1.6))
    return out


EG = np.linspace(ELO, EHI, 900)
MU = mu(EG)
AX.ylim = (0, MU.max() * 1.15)


def energy(t):
    u = clamp((t - 0.45) / (6.25 - 0.45))
    u = 0.5 - 0.5 * math.cos(math.pi * u)   # gentle ease in and out
    return ELO + (EHI - ELO) * u


def fade(t):
    return 1.0 - ramp(t, 7.25, 7.9)


def activation(t, ez):
    # time when the sweep crossed the edge -> smooth turn-on over ~0.18 s
    E = energy(t)
    on = clamp((E - ez) / 6.0)
    return smooth(on) * fade(t)


def draw_atom(ctx, x, y, sym, nval, act, t, kx):
    # bubble
    glow(ctx, x, y, 136, CRIMSON, 0.20 * act)
    src(ctx, IVORY, 0.9)
    ctx.arc(x, y, 90, 0, 2 * math.pi)
    ctx.fill_preserve()
    ctx.set_source_rgba(*mix(RULE, CRIMSON, act, 1.0))
    ctx.set_line_width(2.0 + 1.2 * act)
    ctx.stroke()
    # shells
    src(ctx, SLATE, 0.55)
    ctx.set_line_width(1.6)
    ctx.arc(x, y, 36, 0, 2 * math.pi)
    ctx.stroke()
    ctx.set_dash([6, 5])
    ctx.arc(x, y, 67, 0, 2 * math.pi)
    ctx.stroke()
    ctx.set_dash([])
    # nucleus
    g = cairo.RadialGradient(x - 7, y - 7, 1, x, y, 22)
    for off, col in ((0, "#7A858B"), (1, INK)):
        c = hexrgb(col)
        g.add_color_stop_rgb(off, *c[:3])
    ctx.set_source(g)
    ctx.arc(x, y, 21, 0, 2 * math.pi)
    ctx.fill()
    text(ctx, x, y + 10, sym, 30, IVORY, 1.0, "c")
    # valence electrons
    for i in range(nval):
        a = math.radians(-45 + (i + 0.5) * 360 / nval)
        electron(ctx, x + 67 * math.cos(a), y + 67 * math.sin(a), 8.5)
    # 1s electrons; the one at -45 deg is the photoelectron site
    a_stay = math.radians(135)
    electron(ctx, x + 36 * math.cos(a_stay), y + 36 * math.sin(a_stay), 9.5)
    a_ej = math.radians(-45)
    ex, ey = x + 36 * math.cos(a_ej), y + 36 * math.sin(a_ej)

    # absorption events: every packet that crosses an active atom ejects a 1s electron
    hole_a = 0.0
    events = []
    for k in range(-1, 9):
        xp = packet_x(t, k)
        tau = (xp - x) / V
        if -0.1 < tau < 1.15:
            events.append((tau, k))
    for tau, k in events:
        if act < 0.05:
            continue
        if 0 <= tau < 0.75:
            hole_a = max(hole_a, act * (1 - ramp(tau, 0.55, 0.75)))
        glow(ctx, ex, ey, 34, CLAY, 0.85 * act * (ramp(tau, -0.08, 0.0) * (1 - ramp(tau, 0.0, 0.35))))
        if 0 <= tau < 1.1:
            ang = a_ej + [0.0, -0.28, 0.26, -0.12][k % 4]
            r = 210 * (tau ** 0.85)
            px, py = ex + r * math.cos(ang), ey + r * math.sin(ang)
            fa = act * (1 - ramp(tau, 0.4, 0.8))
            # streak
            r0 = max(0.0, r - 60)
            g = cairo.LinearGradient(ex + r0 * math.cos(ang), ey + r0 * math.sin(ang), px, py)
            c = hexrgb(SKY)
            g.add_color_stop_rgba(0, c[0], c[1], c[2], 0)
            g.add_color_stop_rgba(1, c[0], c[1], c[2], 0.75 * fa)
            ctx.set_source(g)
            ctx.set_line_width(6)
            ctx.move_to(ex + r0 * math.cos(ang), ey + r0 * math.sin(ang))
            ctx.line_to(px, py)
            ctx.stroke()
            electron(ctx, px, py, 9.5, fa)
    hole(ctx, ex, ey, 9.5, hole_a)
    electron(ctx, ex, ey, 9.5, 1 - hole_a)


def packet_x(t, k):
    return X_START + ((V * t + k * SP) % SPAN)


def transmission_at(x, t):
    amp = 1.0
    for sym, ez, _, j in EDGES:
        ax = AX.X(ez)
        a = activation(t, ez)
        pas = smooth(clamp((x - (ax - 25)) / 50))
        amp *= 1 - 0.36 * a * pas
    return amp


def frame(t):
    surf, ctx = new_frame()
    E = energy(t)
    fd = fade(t)

    # beam guide
    src(ctx, CLAY, 0.18)
    ctx.set_line_width(2)
    ctx.set_dash([2, 7])
    ctx.move_to(0, BEAM_Y)
    ctx.line_to(W, BEAM_Y)
    ctx.stroke()
    ctx.set_dash([])

    # guides from atoms to their edges
    for sym, ez, _, _ in EDGES:
        x = AX.X(ez)
        a = activation(t, ez)
        ctx.set_source_rgba(*mix(MUTED, CRIMSON, a, 0.55 + 0.25 * a))
        ctx.set_line_width(1.6)
        ctx.set_dash([4, 6])
        ctx.move_to(x, BEAM_Y + 94)
        ctx.line_to(x, AX.y1)
        ctx.stroke()
        ctx.set_dash([])

    # wave packets (behind atoms)
    lam = 7800.0 / E
    for k in range(int(SPAN / SP) + 1):
        xp = packet_x(t, k)
        amp = 24 * transmission_at(xp, t)
        wave_packet(ctx, xp, BEAM_Y, 0.0, 78, lam, amp, 2 * math.pi * t * 2.2, CLAY,
                    alpha=0.35 + 0.65 * amp / 24)

    for sym, ez, nval, _ in EDGES:
        draw_atom(ctx, AX.X(ez), BEAM_Y, sym, nval, activation(t, ez), t, 0)

    # photon energy readout
    text(ctx, 34, 66, f"h$ν$ = {E:.0f} eV", 44, INK)

    # spectrum
    AX.frame(ctx, xticks=(300, 400, 500, 600), xlabel="Photon energy (eV)", size=36)
    text(ctx, AX.x0 - 30, (AX.y0 + AX.y1) / 2, "Absorption", 36, SLATE, 1.0, "c", rotate=-math.pi / 2)
    m = EG <= E
    if m.sum() > 1:
        pts = AX.pts(EG[m], MU[m])
        fill_under(ctx, pts, AX.y1, CRIMSON, 0.10 * fd)
        polyline(ctx, pts, CRIMSON, 5.5, fd)
    for sym, ez, _, _ in EDGES:
        a = activation(t, ez)
        if a > 0.01:
            yv = AX.Y(float(mu(ez + 4)))
            text(ctx, AX.X(ez) + 14, yv - 18, f"{sym} 1s", 38, CRIMSON, a)
    # cursor
    cx = AX.X(E)
    ca = fd * ramp(t, 0.0, 0.35)
    src(ctx, CLAY, 0.9 * ca)
    ctx.set_line_width(2.4)
    ctx.set_dash([6, 6])
    ctx.move_to(cx, AX.y0 - 10)
    ctx.line_to(cx, AX.y1)
    ctx.stroke()
    ctx.set_dash([])
    glow(ctx, cx, AX.Y(float(mu(E))), 22, CLAY, 0.45 * ca)
    ctx.new_path()
    src(ctx, CLAY, ca)
    ctx.arc(cx, AX.Y(float(mu(E))), 7, 0, 2 * math.pi)
    ctx.fill()
    return surf
