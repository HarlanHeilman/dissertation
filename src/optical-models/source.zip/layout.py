"""Shared single-column layout (800 x 1200) so the oscillator and step figures align side by side."""
SIZE = (800, 1200)
DUR = 9.0
T0, T1 = 0.4, 6.0
FADE = (8.2, 8.9)
LEG_X = (60, 430)
LEG_Y = (64, 102)
AX_BOX = (120, 165, 760, 470)          # spectrum panel
CP_BOX = (130, 640, 730, 1070)         # complex plane, 600 x 430 px


def cp_ylim(xlim):
    """Top of the Im axis that keeps equal aspect inside CP_BOX for a given Re range."""
    x0, y0, x1, y1 = CP_BOX
    unit = (x1 - x0) / (xlim[1] - xlim[0])
    return (y1 - y0) / unit, unit
