"""Three-slide optical-model story on the defense deck's Title Only layout.
1. Definition (n(E), a complex tensor function of energy) + how beta and delta are obtained.
2. Fine structure, core-level resonances and local bond states.
3. Tensor, transition dipoles and polarization."""
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from lxml import etree
from xml.sax.saxutils import escape

F = "/tmp/out/final/"
GIF = {1: F + "optical-model-1-core-level.gif", 2: F + "optical-model-2-local-bonds.gif",
       3: F + "optical-model-3-complex-index.gif", 4: F + "optical-model-4-tensor.gif",
       5: F + "optical-model-5-arnexafs.gif", "edges": F + "core-level-edges.png"}
CRIM = RGBColor(0xCA, 0x12, 0x37)
INKC = RGBColor(0x1F, 0x1F, 0x1F)
GREY = RGBColor(0x5E, 0x6A, 0x71)
BLUEC = RGBColor(0x2F, 0x5F, 0x8F)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)

TITLES = ["What is an optical model?",
          "Resonances give the index its fine structure",
          "Transition dipoles make the index a tensor",
          "Angle-resolved NEXAFS measures the tensor"]

SRC = ("SOURCE Original animations made for the defense. Spectra are a schematic benzene-ring model built from "
       "the Chapter 2 Gaussian-Dawson oscillators (one π*, two σ*) on an ionization step at 290.3 eV, with the "
       "background δ from a numerical Kramers-Kronig transform over 1 eV to 30 keV. Not a measured dataset.")
NOTES = [
    ["TIME 2.0 min", SRC,
     "SCRIPT Here is the definition we have been building toward. An optical model is the index of refraction, a "
     "complex tensor function of photon energy. Each diagonal component is one minus delta plus i beta. Three words "
     "carry the content. Complex, because beta is absorption and delta is dispersion. Function of energy, because "
     "core-level resonances give it fine structure. Tensor, because molecules absorb along their transition dipoles. "
     "On the right is how we get it. A transmission NEXAFS measurement samples only beta. In the complex plane beta "
     "alone leaves the index somewhere on a horizontal line. Kramers-Kronig then builds delta at each energy from "
     "beta at every energy, and the index traces its loop through the resonances.",
     "TRANSITION Next, where that energy dependence comes from."],
    ["TIME 1.5 min", SRC,
     "SCRIPT On the left is the standard picture. Each core level opens an absorption edge once the photon can free "
     "that electron, so absorption follows a sawtooth in photon energy, and each edge belongs to one element. For "
     "organic films the K edges of carbon, nitrogen, and oxygen at 284, 410, and 543 eV are the ones that matter. On "
     "the right is the carbon edge of a ring molecule. Bonding leaves an empty pi star orbital below the ionization "
     "threshold, so the 1s electron is promoted into a bound, local state and gives a sharp resonance before the "
     "step. Above the step, sigma star resonances sit in the continuum along the bonds. That fine structure is the "
     "molecular fingerprint in beta, and through Kramers-Kronig, in delta.",
     "TRANSITION Each of those resonances also has a direction."],
    ["TIME 1.5 min", SRC,
     "SCRIPT Absorption follows the square of E dot mu, the projection of the field on the transition dipole. The "
     "pi star dipole stands normal to the ring plane, and the sigma star dipoles lie in it. In this flat-lying film, "
     "with E in plane the pi star resonance vanishes and the sigma star region carries the absorption. Rotating E to "
     "the surface normal lights the pi star resonance instead. The spectrum moves between beta xx and beta zz, and the "
     "matching diagonal component of n is the one being probed.",
     "TRANSITION So how do we measure each component?"],
    ["TIME 2.0 min", SRC,
     "SCRIPT We measure the tensor by angle-resolved NEXAFS with p-polarized light. For a pi star vector orbital "
     "the transition intensity is one third times one plus one half of three cos squared theta minus one, times three "
     "cos squared gamma minus one, with theta the incident angle and gamma the molecular tilt. At grazing incidence "
     "the field lies close to the surface normal and samples mostly zz. At normal incidence it lies in plane and "
     "samples xx. At the magic angle, 54.7 degrees, the first factor vanishes, so the intensity is one third at any "
     "tilt and the spectrum is the isotropic average. The difference between grazing and normal incidence is the "
     "linear dichroism, and with the uniaxial condition, two beta xx plus beta zz equals three beta iso, it fixes both "
     "components. For flat-lying rings, gamma is zero, the pi star resonance lands entirely in zz at three times the "
     "isotropic strength, and xx suppresses it completely.",
     "TRANSITION For a whole molecule we need many such oscillators, each along its own dipole."],
]
NS = ('xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
      'xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"')


def write_notes(slide, paras):
    tree = slide.notes_slide.shapes._spTree
    for el in list(tree):
        if el.tag.endswith("}sp"):
            tree.remove(el)
    body = "<a:p><a:endParaRPr/></a:p>".join(
        f'<a:p><a:r><a:rPr lang="en-US"/><a:t>{escape(t)}</a:t></a:r></a:p>' for t in paras)
    for xml in (
        f'<p:sp {NS}><p:nvSpPr><p:cNvPr id="2" name="Slide Image Placeholder 1"/><p:cNvSpPr><a:spLocks noGrp="1" '
        f'noRot="1" noChangeAspect="1"/></p:cNvSpPr><p:nvPr><p:ph type="sldImg" idx="2"/></p:nvPr></p:nvSpPr>'
        f'<p:spPr/></p:sp>',
        f'<p:sp {NS}><p:nvSpPr><p:cNvPr id="3" name="Notes Placeholder 2"/><p:cNvSpPr><a:spLocks noGrp="1"/>'
        f'</p:cNvSpPr><p:nvPr><p:ph type="body" sz="quarter" idx="3"/></p:nvPr></p:nvSpPr><p:spPr/><p:txBody>'
        f'<a:bodyPr/><a:lstStyle/>{body}</p:txBody></p:sp>',
    ):
        tree.append(etree.fromstring(xml))


def strip(slide):
    for shp in list(slide.shapes):
        if shp.is_placeholder:
            continue
        if shp.shape_type == 13:
            rid = shp._element.xpath(".//a:blip/@r:embed")[0]
            shp._element.getparent().remove(shp._element)
            slide.part.drop_rel(rid)
        else:
            shp._element.getparent().remove(shp._element)


def set_title(slide, text):
    p = slide.shapes.title.text_frame.paragraphs[0]
    for r in p.runs[1:]:
        r._r.getparent().remove(r._r)
    p.runs[0].text = text


def add_runs(p, runs, size, color=INKC):
    """runs: list of (text, style) with style in None, 'b', 'i', 'sub', 'isub', 'sup'."""
    for txt, sty in runs:
        r = p.add_run()
        r.text = txt
        f = r.font
        f.size = Pt(size)
        f.color.rgb = color
        f.bold = sty == "b"
        f.italic = sty in ("i",)
        if sty in ("sub", "sup"):
            r._r.get_or_add_rPr().set("baseline", "-25000" if sty == "sub" else "30000")


def textbox(slide, x, y, w, h, name, anchor=MSO_ANCHOR.TOP):
    tb = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tb.name = name
    tf = tb.text_frame
    tf.word_wrap = True
    for side in ("margin_left", "margin_right", "margin_top", "margin_bottom"):
        setattr(tf, side, 0)
    tf.vertical_anchor = anchor
    return tb, tf


def para(tf, runs, size, color=INKC, first=False, space_after=0, align=PP_ALIGN.LEFT):
    p = tf.paragraphs[0] if first else tf.add_paragraph()
    p.alignment = align
    if space_after:
        p.space_after = Pt(space_after)
    add_runs(p, runs, size, color)
    return p


def badge(slide, label, x, y, d=0.40, size=14, name="Badge"):
    b = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(x), Inches(y), Inches(d), Inches(d))
    b.name = name
    b.fill.solid()
    b.fill.fore_color.rgb = CRIM
    b.line.fill.background()
    b.shadow.inherit = False
    tf = b.text_frame
    for side in ("margin_left", "margin_right", "margin_top", "margin_bottom"):
        setattr(tf, side, 0)
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER
    add_runs(p, [(label, "b")], size, WHITE)


def header(slide, label, text, x, y, w, size=18):
    badge(slide, label, x, y, name=f"Badge {label}")
    tb, tf = textbox(slide, x + 0.54, y - 0.02, w - 0.54, 0.44, f"Header {label}", MSO_ANCHOR.MIDDLE)
    para(tf, [(text, "b")], size, CRIM, first=True)


def gif(slide, k, x, y, w, descr):
    pic = slide.shapes.add_picture(GIF[k], Inches(x), Inches(y), Inches(w), Inches(w * 2 / 3))
    pic.name = f"Animation {k}" if isinstance(k, int) else "Core-level edge diagram"
    pic._element.xpath(".//p:cNvPr")[0].set("descr", descr)
    return pic


def card(slide, x, y, w, h, name):
    c = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x), Inches(y), Inches(w), Inches(h))
    c.name = name
    c.adjustments[0] = 0.06
    c.fill.solid()
    c.fill.fore_color.rgb = WHITE
    c.line.fill.background()
    c.shadow.inherit = False
    return c


def n_comp(ii, energy=True):
    r = [("n", "i"), (ii, "sub")]
    if energy:
        r += [("(", None), ("E", "i"), (")", None)]
    return r


prs = Presentation("/tmp/dk/base.pptx")
slides = list(prs.slides)
for i, s in enumerate(slides):
    strip(s)
    set_title(s, TITLES[i])
    write_notes(s, NOTES[i])

# ---------------------------------------------------------------- slide 1, definition
s = slides[0]
L = 0.80
tb, tf = textbox(s, L, 2.18, 5.55, 0.70, "Definition")
para(tf, [("An optical model is the ", None), ("index of refraction", "b"),
          (", a complex tensor function of photon energy", None)], 19, first=True)

card(s, L, 2.98, 5.55, 1.98, "Definition card")
# n(E) = ( matrix )
tb, tf = textbox(s, L + 0.22, 3.30, 1.05, 0.5, "Matrix lhs", MSO_ANCHOR.MIDDLE)
para(tf, [("n", "i"), ("(", None), ("E", "i"), (") =", None)], 20, first=True)
MX, MY, CW, RH = L + 1.42, 3.10, 0.98, 0.30
br = s.shapes.add_shape(MSO_SHAPE.DOUBLE_BRACKET, Inches(MX - 0.10), Inches(MY - 0.02),
                        Inches(3 * CW + 0.10), Inches(3 * RH + 0.04))
br.name = "Matrix brackets"
br.fill.background()
br.line.color.rgb = INKC
br.line.width = Pt(1.5)
br.shadow.inherit = False
br.adjustments[0] = 0.12
names = ["xx", "yy", "zz"]
for i in range(3):
    for j in range(3):
        tb, tf = textbox(s, MX + j * CW, MY + i * RH, CW - 0.1, RH, f"M{i}{j}", MSO_ANCHOR.MIDDLE)
        if i == j:
            para(tf, n_comp(names[i]), 16, first=True, align=PP_ALIGN.CENTER)
        else:
            para(tf, [("0", None)], 16, GREY, first=True, align=PP_ALIGN.CENTER)
tb, tf = textbox(s, L + 0.22, 4.18, 5.1, 0.42, "Component", MSO_ANCHOR.MIDDLE)
para(tf, n_comp("ii") + [(" = 1 − ", None), ("δ", "i"), ("ii", "sub"), ("(", None), ("E", "i"), (") + ", None),
                         ("iβ", "i"), ("ii", "sub"), ("(", None), ("E", "i"), (")", None)], 20, first=True,
     align=PP_ALIGN.CENTER)
tb, tf = textbox(s, L + 0.22, 4.58, 5.1, 0.30, "Component gloss")
para(tf, [("δ", "i"), (" dispersion (phase), ", None), ("β", "i"), (" absorption", None)], 14, GREY, first=True,
     align=PP_ALIGN.CENTER)

ROWS = [("1", "Complex", [("β", "i"), (" is measured by NEXAFS, and Kramers-Kronig fixes ", None), ("δ", "i"),
                          (" from it", None)]),
        ("2", "Function of energy", [("Core-level resonances and bond fine structure", None)]),
        ("3", "Tensor", [("Transition dipoles set ", None)] + n_comp("xx", False) + [(", ", None)]
         + n_comp("yy", False) + [(", ", None)] + n_comp("zz", False))]
for r, (lab, head, body) in enumerate(ROWS):
    y = 5.16 + r * 0.62
    badge(s, lab, L, y + 0.04, d=0.34, size=12, name=f"Row badge {lab}")
    tb, tf = textbox(s, L + 0.48, y, 5.05, 0.6, f"Row {lab}")
    para(tf, [(head, "b")], 15, CRIM, first=True)
    para(tf, body, 14)

GX, GW = 6.80, 5.75
gif(s, 3, GX, 2.22, GW, "Animated schematic, transmission NEXAFS measures beta, Kramers-Kronig builds delta, "
                         "and n(E) traces a loop in the complex plane")
tb, tf = textbox(s, GX, 6.15, GW, 0.75, "Caption 3")
para(tf, [("How we get it. ", "b"), ("NEXAFS samples ", None), ("β", "i"),
          (", which alone leaves ", None), ("n", "i"), (" on a line in the complex plane. Kramers-Kronig builds ", None),
          ("δ", "i"), (" from ", None), ("β", "i"), (" at every energy", None)], 14, first=True)

# ---------------------------------------------------------------- slide 2, fine structure
s = slides[1]
W2, XS = 5.60, [0.80, 6.95]
PAN = [("edges", "a", "Each core level opens an edge",
        [("Absorption jumps once the photon can free a core electron. The K edges of C, N, and O sit near 284, 410, "
          "and 543 eV", None)],
        "Diagram of atomic core levels from 1s to 3d, the K, L, and M edges each opens, and the sawtooth absorption "
        "that results"),
       (2, "b", "Bonds create local empty states",
        [("Below the ionization step a C 1s electron is promoted into the bound π* orbital. Above it, σ* "
          "resonances sit along the bonds", None)],
        "Animated schematic, a C 1s electron on a ring carbon is promoted into pi star and sigma star orbitals as "
        "the NEXAFS spectrum builds")]
for col, (k, lab, head, cap, descr) in enumerate(PAN):
    x = XS[col]
    header(s, lab, head, x, 2.22, W2)
    gif(s, k, x, 2.74, W2, descr)
    tb, tf = textbox(s, x, 6.52, W2, 0.62, f"Caption {lab}")
    para(tf, cap, 15, first=True)

# ---------------------------------------------------------------- slide 3, tensor
s = slides[2]
gif(s, 4, 0.70, 2.25, 6.90, "Animated schematic, polarization rotates from in plane to the surface normal, "
                             "flat-lying ring molecules respond by their pi star dipoles, and the spectrum moves "
                             "between beta xx and beta zz")
RX, RW = 7.95, 4.60
card(s, RX, 2.75, RW, 3.35, "Tensor card")
tb, tf = textbox(s, RX + 0.30, 2.98, RW - 0.6, 2.95, "Tensor relations")
para(tf, [("Absorption follows the projection of the field on each transition dipole", None)], 16, first=True,
     space_after=4)
para(tf, [("β", "i"), (" ∝ |", None), ("E", "b"), (" · ", None), ("μ", "b"), ("|²", None)], 22,
     space_after=14, align=PP_ALIGN.CENTER)
para(tf, [("π*", "b"), (" dipoles stand normal to the ring plane, and ", None), ("σ*", "b"),
          (" dipoles lie in it", None)], 16, space_after=10)
para(tf, [("In a flat-lying film, ", None), ("π*", "b"), (" strength sits in ", None)] + n_comp("zz", False)
     + [(" and ", None), ("σ*", "b"), (" strength in ", None)] + n_comp("xx", False), 16, space_after=10)
para(tf, [("A uniaxial film gives ", None)] + n_comp("xx", False) + [(" = ", None)] + n_comp("yy", False)
     + [(" ≠ ", None)] + n_comp("zz", False), 16)

# ---------------------------------------------------------------- slide 4, ARNEXAFS
s = slides[3]
gif(s, 5, 0.70, 2.25, 6.90, "Animated schematic, p-polarized NEXAFS at grazing, normal, and magic-angle incidence, "
                             "the linear dichroism, and the uniaxial beta xx and beta zz derived from them")
card(s, RX, 2.62, RW, 3.55, "ARNEXAFS card")
tb, tf = textbox(s, RX + 0.30, 2.84, RW - 0.6, 3.2, "ARNEXAFS relations")
para(tf, [("π* transition intensity, p-polarized light", None)], 15, first=True, space_after=4)
para(tf, [("I", "i"), (" = ⅓[1 + ½(3cos² ", None), ("ϑ", "i"), (" − 1)(3cos² ", None), ("γ", "i"), (" − 1)]", None)],
     16, space_after=2, align=PP_ALIGN.CENTER)
para(tf, [("ϑ", "i"), (" incident angle, ", None), ("γ", "i"), (" molecular tilt", None)], 13, GREY,
     space_after=10, align=PP_ALIGN.CENTER)
para(tf, [("At the magic angle, 54.7°, the first factor vanishes and ", None), ("I", "i"),
          (" = ⅓ at any tilt, the isotropic spectrum", None)], 15, space_after=8)
para(tf, [("Flat rings, ", None), ("γ", "i"), (" = 0, give ", None), ("I", "i"), (" ≈ 1 at grazing and 0 at normal "
          "incidence, so ", None), ("β", "i"), ("zz", "sub"), (" = 3", None), ("β", "i"), ("iso", "sub"), (" and ", None),
          ("β", "i"), ("xx", "sub"), (" = 0", None)], 15, space_after=8)
para(tf, [("Linear dichroism and the uniaxial condition 2", None), ("β", "i"), ("xx", "sub"), (" + ", None),
          ("β", "i"), ("zz", "sub"), (" = 3", None), ("β", "i"), ("iso", "sub"), (" return both components", None)], 15)

prs.save("/tmp/out/final/optical-model-slides.pptx")
print("saved")
