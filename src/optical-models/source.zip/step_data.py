"""Precompute erf and arctan ionization steps (equal FWHM of the broadening kernel) and their KK delta."""
import numpy as np
from scipy.special import erf
IP = 290.3
SIG = 0.7 / np.sqrt(2)                 # erf((E-IP)/0.7) is the integral of a Gaussian with this sigma
FWHM = 2 * np.sqrt(2 * np.log(2)) * SIG
GAM = FWHM                              # Lorentzian kernel with the same FWHM


def decay(E):
    return (np.maximum(np.asarray(E, float), IP) / IP) ** -2.6


def b_erf(E):
    E = np.asarray(E, float)
    return 0.5 * (1 + erf((E - IP) / 0.7)) * decay(E)


def b_atan(E):
    E = np.asarray(E, float)
    return (0.5 + np.arctan(2 * (E - IP) / GAM) / np.pi) * decay(E)


g = np.unique(np.concatenate([np.logspace(-1, np.log10(3e4), 120000), np.linspace(270, 340, 40000),
                              np.linspace(288, 293, 10000)]))


def kk(bf, Ev):
    bg = bf(g); fg = g * bg; a, b = g[0], g[-1]; out = []
    for e in Ev:
        fe = e * float(bf(e)); d = e * e - g * g; m = np.abs(d) > 1e-9
        it = np.zeros_like(g); it[m] = (fg[m] - fe) / d[m]
        sing = (1 / (2 * e)) * np.log(((e + b) * (e - a)) / ((b - e) * (e + a)))
        out.append((2 / np.pi) * (np.trapezoid(it, g) + fe * sing))
    return np.array(out)


if __name__ == "__main__":
    E = np.linspace(280, 320, 801)
    Et = np.logspace(np.log10(320), np.log10(2.5e4), 140)
    out = dict(E=E, Et=Et)
    for nm, f in (("erf", b_erf), ("atan", b_atan)):
        out[nm + "_B"] = f(E); out[nm + "_D"] = kk(f, E)
        out[nm + "_Bt"] = f(Et); out[nm + "_Dt"] = kk(f, Et)
    np.savez("step2.npz", **out)
    print("FWHM", FWHM)
    for nm in ("erf", "atan"):
        print(nm, [(e, round(float(np.interp(e, E, out[nm + "_B"])), 3), round(float(np.interp(e, E, out[nm + "_D"])), 3))
                   for e in (280, 289, 290.3, 292, 320)])
