"""GIF 6. Three causal oscillator bases with equal peak beta and equal FWHM (0.8 eV at 285.1 eV).
Rows show beta (solid, filled) and its Kramers-Kronig partner delta (dashed) for
  Lorentz (damped driven oscillator), Gaussian with Dawson delta, Kuzmenko triangle.
A shared energy cursor traces each basis in one equal-aspect complex plane (Re n - 1 = -delta, Im n = beta):
the Lorentzian draws a circle, the Gaussian a wider elongated loop, the triangle a loop with kinks at its nodes."""
import math
import numpy as np
from scipy.special import dawsn
from style import *

DUR = 10.0
E0, F = 285.1, 0.8
ELO, EHI = 281.0, 289.2
EG = np.linspace(ELO, EHI, 1641)

# Lorentz, full damped-driven form; chi = f / (E0^2 - E^2 - i E Gamma), n - 1 ~ chi / 2
chi = 1.0 / (E0 ** 2 - EG ** 2 - 1j * EG * F)
LB, LD = chi.imag, -chi.real
s = LB.max()
LB, LD = LB / s, LD / s
# Gaussian with Dawson partner
w = F / (2 * math.sqrt(math.log(2)))
xg = (EG - E0) / w
GB, GD = np.exp(-xg ** 2), 2 / math.sqrt(math.pi) * dawsn(xg)
# Kuzmenko triangle (nodes at E0 - F, E0, E0 + F) with its analytic partner


def _xlx(x):
    ax = np.abs(x)
    return np.where(ax > 1e-12, x * np.log(np.maximum(ax, 1e-300)), 0.0)


xt = (EG - E0) / F
TB = np.clip(1 - np.abs(xt), 0, None)
TD = (_xlx(xt + 1) + _xlx(xt - 1) - 2 * _xlx(xt)) / math.pi

BASES = [
    ("Lorentz", "damped driven oscillator", INK, LB, LD),
    ("Gaussian-Dawson", "inhomogeneous broadening", CRIMSON, GB, GD),
    ("Kuzmenko triangle", "piecewise linear, model free", CLAY, TB, TD),
]

ROW_Y = [56, 300, 544]          # top of each row
ROW_H = 170
PX0, PX1 = 372, 690
CP = Axes(790, 216, 1162, 545, (-0.78, 0.78), (0, 1.38))   # 372 px / 1.56 = 238.5 px/unit; 329/1.38 = 238.5


def row_axes(i):
    y = ROW_Y[i]
    return Axes(PX0, y + 18, PX1, y + ROW_H, (ELO, EHI), (-0.72, 1.12))


def _g(E, e0, s):
    return np.exp(-0.5 * ((E - e0) / s) ** 2)


DWELL = 1 + 7 * _g(EG, E0, 0.9)
CUM = np.concatenate([[0], np.cumsum(0.5 * (DWELL[1:] + DWELL[:-1]) * np.diff(EG))])
CUM /= CUM[-1]
T0, T1 = 0.4, 6.4
FADE = (9.1, 9.8)


def energy(t):
    u = clamp((t - T0) / (T1 - T0))
    u = 0.5 - 0.5 * math.cos(math.pi * u)
    return float(np.interp(u, CUM, EG))


def at(arr, E):
    return float(np.interp(E, EG, arr))


def frame(t):
    surf, ctx = new_frame()
    E = energy(t)
    fd = 1 - ramp(t, *FADE)
    ca = fd * ramp(t, 0.0, 0.35)
    m = EG <= E

    for i, (name, sub, col, B, D) in enumerate(BASES):
        ax = row_axes(i)
        y = ROW_Y[i]
        text(ctx, 40, y + 62, name, 34, col)
        text(ctx, 40, y + 102, sub, 26, SLATE, 0.95)
        # axes, zero line, no ticks except the bottom row
        src(ctx, RULE)
        ctx.set_line_width(1.4)
        ctx.move_to(ax.x0, ax.Y(0))
        ctx.line_to(ax.x1, ax.Y(0))
        ctx.stroke()
        src(ctx, SLATE, 0.9)
        ctx.set_line_width(3)
        ctx.move_to(ax.x0, ax.y0)
        ctx.line_to(ax.x0, ax.y1)
        ctx.stroke()
        if i == 2:
            ax2 = Axes(PX0, y + 18, PX1, y + ROW_H, (ELO, EHI), (-0.72, 1.12))
            src(ctx, SLATE, 0.9)
            ctx.set_line_width(3)
            ctx.move_to(ax2.x0, ax2.y1)
            ctx.line_to(ax2.x1, ax2.y1)
            ctx.stroke()
            for v in (282, 285, 288):
                xv = ax2.X(v)
                ctx.move_to(xv, ax2.y1)
                ctx.line_to(xv, ax2.y1 + 10)
                ctx.stroke()
                text(ctx, xv, ax2.y1 + 42, f"{v}", 30, SLATE, 1.0, "c")
            text(ctx, (PX0 + PX1) / 2, ax2.y1 + 80, "Photon energy (eV)", 30, SLATE, 1.0, "c")
        # triangle mesh: neighbouring basis elements, faint
        if i == 2:
            for k in (-2, -1, 1, 2):
                c0 = E0 + k * F
                src(ctx, CLAY, 0.35)
                ctx.set_line_width(1.8)
                ctx.set_dash([5, 5])
                ctx.move_to(ax.X(c0 - F), ax.Y(0))
                ctx.line_to(ax.X(c0), ax.Y(1))
                ctx.line_to(ax.X(c0 + F), ax.Y(0))
                ctx.stroke()
                ctx.set_dash([])
        if m.sum() > 1:
            pb = ax.pts(EG[m], B[m])
            fill_under(ctx, pb, ax.Y(0), col, 0.14 * fd)
            polyline(ctx, pb, col, 4.6, fd)
            polyline(ctx, ax.pts(EG[m], D[m]), col, 3.2, 0.9 * fd, dash=[9, 7])
        if i == 0:
            la = fd * ramp(t, T1 + 0.1, T1 + 0.6)
            text(ctx, ax.X(285.55), ax.Y(0.92), "$β$", 36, col, la)
            text(ctx, ax.X(286.15), ax.Y(-0.18), "$δ$", 36, col, la)
        # cursor dots
        for arr in (B, D):
            yv = ax.Y(at(arr, E))
            ctx.new_path()
            src(ctx, CLAY, ca)
            ctx.arc(ax.X(E), yv, 6, 0, 2 * math.pi)
            ctx.fill()

    # shared cursor through the three rows
    cx = row_axes(0).X(E)
    src(ctx, CLAY, 0.85 * ca)
    ctx.set_line_width(2.4)
    ctx.set_dash([6, 6])
    ctx.move_to(cx, ROW_Y[0] + 10)
    ctx.line_to(cx, ROW_Y[2] + ROW_H)
    ctx.stroke()
    ctx.set_dash([])

    # complex plane
    x0 = CP.X(0.0)
    src(ctx, SLATE, 0.9)
    ctx.set_line_width(3)
    ctx.move_to(CP.x0, CP.y1)
    ctx.line_to(CP.x1, CP.y1)
    ctx.stroke()
    ctx.move_to(x0, CP.y1)
    ctx.line_to(x0, CP.y0)
    ctx.stroke()
    arrow_head(ctx, CP.x1 + 4, CP.y1, 0, 16, SLATE, 0.9)
    arrow_head(ctx, x0, CP.y0 - 4, -math.pi / 2, 16, SLATE, 0.9)
    text(ctx, CP.x1 + 6, CP.y1 + 46, "Re $n$ − 1", 32, SLATE, 1.0, "r")
    text(ctx, x0 - 14, CP.y0 + 12, "Im $n$", 32, SLATE, 1.0, "r")
    text(ctx, (CP.x0 + CP.x1) / 2, 158, "equal peak and FWHM", 30, SLATE, 0.95, "c")
    order = [2, 1, 0]
    for i in order:
        name, sub, col, B, D = BASES[i]
        if m.sum() > 1:
            polyline(ctx, CP.pts(-D[m], B[m]), col, 4.2 if i else 3.6, fd)
    for i in order:
        name, sub, col, B, D = BASES[i]
        px, py = CP.X(-at(D, E)), CP.Y(at(B, E))
        glow(ctx, px, py, 20, col, 0.35 * ca)
        ctx.new_path()
        src(ctx, col, ca)
        ctx.arc(px, py, 8, 0, 2 * math.pi)
        ctx.fill()
    la = fd * ramp(t, T1 + 0.2, T1 + 0.8)
    text(ctx, CP.X(0.0), CP.Y(0.5) + 12, "circle", 30, INK, la, "c")
    text(ctx, CP.X(-0.64) - 8, CP.Y(0.30), "wider", 30, CRIMSON, la, "r")
    text(ctx, 1162, CP.Y(1.30), "kinks at nodes", 28, CLAY, la, "r")
    text(ctx, CP.X(-0.70), CP.Y(0.0) + 82, "Lorentz tails stay open", 26, INK, la, "l")
    # direction of travel
    a = ramp(t, T1 + 0.2, T1 + 0.8) * fd
    if a > 0.01:
        cx0, cy0, r = CP.X(0.0), CP.Y(0.5), 0.5 * 238.5
        ctx.new_path()
        src(ctx, SLATE, 0.6 * a)
        ctx.set_line_width(2)
        th0, th1 = math.radians(-30), math.radians(-150)
        ctx.arc_negative(cx0, cy0, r + 26, th0, th1)
        ctx.stroke()
        arrow_head(ctx, cx0 + (r + 26) * math.cos(th1), cy0 + (r + 26) * math.sin(th1),
                   th1 - math.pi / 2, 14, SLATE, 0.6 * a)
    return surf


if __name__ == "__main__":
    i = int(np.argmax(-TD)); print("triangle loop x-range", (-TD).min(), (-TD).max(), "gauss", (-GD).min(), (-GD).max(),
                                   "lorentz", (-LD).min(), (-LD).max())
