"""GIF 11. ZnPc version of the local-bonds figure, cycling three StoBe transition-potential final states, each
excited from a different carbon core site. Geometry and orbitals are the dft-learn znpc-cif run:
  lobes  = signed p amplitude of the final MO at 0.7 A from each atom (contracted shells normalized),
  dipole = <1s|r|psi_f> integrated on a radial x angular grid at the core-hole atom (znpc_tdm.py),
  angle  = from the normal of the local isoindole plane.
Spectrum = all DFT sticks (four sites, aligned energies) broadened by their widths; the state's cluster is shaded."""
import math, pickle
import numpy as np
import pandas as pd
from style import *

DUR = 10.2
PER = DUR / 3
S = pickle.load(open("/home/claude/omgif/znpc_states.pkl", "rb"))
ST = pd.read_csv("/home/claude/znpc_data/data/csv/znpc_sticks_tensor.csv")

ELEV = math.radians(34)
AZ = math.radians(95)        # chosen so all three dipoles lie close to the view plane
SC = 44.0                 # px per Angstrom
CX, CY = 400, 300
ROSE = "#E3A9B3"
XYZ = S[0]["xyz"] - S[0]["xyz"][-1]       # Zn at the origin
ZN = S[0]["Z"]
NAMES = S[0]["names"]
SITE_NAME = {"C1": "C1, $α$ carbon", "C2": "C2, bridgehead carbon", "C3": "C3, outer benzo carbon",
             "C4": "C4, outer benzo carbon"}


def rot(p):
    c, s = math.cos(AZ), math.sin(AZ)
    x, y, z = p[..., 0], p[..., 1], p[..., 2]
    return np.stack([c * x - s * y, s * x + c * y, z], -1)


def proj(p):
    """Orthographic view from the front (-y) at elevation ELEV. Returns screen x, y and depth (larger = nearer)."""
    r = rot(np.asarray(p, float))
    x, y, z = r[..., 0], r[..., 1], r[..., 2]
    up = y * math.sin(ELEV) + z * math.cos(ELEV)
    depth = -y * math.cos(ELEV) + z * math.sin(ELEV)
    return CX + SC * x, CY - SC * up, depth


def bonds():
    out = []
    n = len(XYZ)
    for i in range(n):
        for j in range(i + 1, n):
            d = np.linalg.norm(XYZ[i] - XYZ[j])
            zi, zj = ZN[i], ZN[j]
            if 1 in (zi, zj):
                if d < 1.2:
                    out.append((i, j, "h"))
            elif 30 in (zi, zj):
                if d < 2.15:
                    out.append((i, j, "zn"))
            elif d < 1.6:
                out.append((i, j, "cc"))
    return out


BONDS = bonds()
SX, SY, SD = proj(XYZ)
DMIN, DMAX = SD.min(), SD.max()


def depth_alpha(d):
    return 0.62 + 0.38 * (d - DMIN) / (DMAX - DMIN)


# ------------------------------------------------------------------ spectrum
EG = np.linspace(282, 302, 1201)


def envelope(rows):
    y = np.zeros_like(EG)
    for en, os_, w in zip(rows.en, rows.os, rows.wid):
        y += os_ / (w * math.sqrt(2 * math.pi)) * np.exp(-0.5 * ((EG - en) / w) ** 2)
    return y


ENV = envelope(ST)
CL_ENV = {st["cluster"]: envelope(ST[ST.cluster == st["cluster"]]) for st in S}
AXS = Axes(110, 612, 1150, 720, (282, 302), (0, float(ENV.max()) * 1.12))


def state_phase(t):
    k = int(t // PER) % 3
    u = t - k * PER
    return k, u


def env_alpha(u):
    return ramp(u, 0.45, 0.95) * (1 - ramp(u, PER - 0.45, PER - 0.05))


def draw_lobe(ctx, c3, v3, size, sign, a, prims):
    """One half of a p dumbbell: prolate ellipsoid centred at c3 along unit v3 (3D), projected."""
    cx, cy, cd = proj(c3)
    tip = proj(c3 + v3)
    dx, dy = tip[0] - cx, tip[1] - cy
    L = math.hypot(dx, dy)
    ang = math.atan2(dy, dx) if L > 1e-6 else 0.0
    semi_major = max(0.27 * size, 0.52 * size * L / SC)
    semi_minor = 0.27 * size

    def paint(ctx):
        ctx.save()
        ctx.translate(cx, cy)
        ctx.rotate(ang)
        ctx.scale(semi_major * SC, semi_minor * SC)
        ctx.arc(0, 0, 1, 0, 2 * math.pi)
        ctx.restore()
        src(ctx, IVORY, 0.35 * a)
        ctx.fill_preserve()
        src(ctx, CRIMSON if sign > 0 else SKY, 0.62 * a)
        ctx.fill_preserve()
        src(ctx, CRIMSON if sign > 0 else BLUE, 0.85 * a)
        ctx.set_line_width(1.6)
        ctx.stroke()
    prims.append((cd + 0.01, paint))


def frame(t):
    surf, ctx = new_frame()
    k, u = state_phase(t)
    st = S[k]
    exc = st["exc"]
    la = env_alpha(u)
    prims = []

    # bonds
    for i, j, kind in BONDS:
        d = 0.5 * (SD[i] + SD[j])

        def paint(ctx, i=i, j=j, kind=kind, d=d):
            al = depth_alpha(d)
            col, w = {"cc": (DEEP, 5.0), "h": (SLATE, 3.2), "zn": (SLATE, 2.6)}[kind]
            src(ctx, col, al)
            ctx.set_line_width(w)
            if kind == "zn":
                ctx.set_dash([5, 5])
            ctx.move_to(SX[i], SY[i])
            ctx.line_to(SX[j], SY[j])
            ctx.stroke()
            ctx.set_dash([])
        prims.append((d - 0.02, paint))
    # atoms
    for i in range(len(XYZ)):
        def paint(ctx, i=i):
            al = depth_alpha(SD[i])
            z = ZN[i]
            ctx.new_path()
            if z == 30:
                g = cairo.RadialGradient(SX[i] - 6, SY[i] - 6, 1, SX[i], SY[i], 20)
                for off, c in ((0, "#8E979B"), (1, INK)):
                    cc = hexrgb(c)
                    g.add_color_stop_rgb(off, *cc[:3])
                ctx.set_source(g)
                ctx.arc(SX[i], SY[i], 17, 0, 2 * math.pi)
                ctx.fill()
                text(ctx, SX[i], SY[i] + 8, "Zn", 22, IVORY, 1.0, "c")
                return
            r, fill, edge = {1: (5.5, IVORY, MUTED), 6: (6.5, IVORY, DEEP), 7: (7.5, ICE, NAVY)}.get(z if z != 6 or i != exc else 6, (6.5, IVORY, DEEP))
            if i == exc:
                r = 9.5
            src(ctx, fill, al)
            ctx.arc(SX[i], SY[i], r, 0, 2 * math.pi)
            ctx.fill_preserve()
            src(ctx, edge, al)
            ctx.set_line_width(2.4 if z != 1 else 1.6)
            ctx.stroke()
        prims.append((SD[i], paint))

    # final-state lobes of the current state
    lob = st["lobes"]
    mag = np.linalg.norm(lob, axis=1)
    m = mag.max()
    near = np.linalg.norm(XYZ - XYZ[exc], axis=1) < 1.6          # core-hole atom and its bonded neighbours
    show = (mag > 0.42 * m) | (near & (mag > 0.08 * m))
    for i in np.where(show)[0]:
        a = max(mag[i] / m, 0.35 if near[i] else 0.0)
        v = lob[i] / mag[i]
        size = 0.45 + 0.65 * math.sqrt(a)
        off = 0.50 * size
        draw_lobe(ctx, XYZ[i] + v * off, v, size, +1, la * (0.45 + 0.55 * a), prims)
        draw_lobe(ctx, XYZ[i] - v * off, -v, size, -1, la * (0.45 + 0.55 * a), prims)

    for d, paint in sorted(prims, key=lambda p: p[0]):
        paint(ctx)

    # photon arriving at the core-hole atom, then the core glow
    ex, ey = SX[exc], SY[exc]
    pa = ramp(u, 0.0, 0.1) * (1 - ramp(u, 0.5, 0.62))
    if pa > 0.01:
        s0 = clamp(u / 0.55)
        ang = math.radians(35)
        L = 260 * (1 - s0)
        px, py = ex - L * math.cos(ang), ey - L * math.sin(ang)
        wave_packet(ctx, px, py, ang, 46, 14, 15, 2 * math.pi * 3 * t, CLAY, pa)
    ga = ramp(u, 0.45, 0.6) * (1 - ramp(u, PER - 0.45, PER - 0.05))
    glow(ctx, ex, ey, 44, CLAY, 0.9 * ga)
    ctx.new_path()
    src(ctx, CLAY, 0.4 + 0.6 * ga)
    ctx.arc(ex, ey, 5.5, 0, 2 * math.pi)
    ctx.fill()

    # local normal and transition dipole at the core-hole atom
    th = st["theta"]
    col = mix(DEEP, NAVY, math.sin(math.radians(th)) ** 2)
    nrm, mu = st["normal"], st["tdm"]
    c0 = XYZ[exc]
    a0 = proj(c0 - 1.9 * nrm)
    a1 = proj(c0 + 1.9 * nrm)
    src(ctx, SLATE, 0.7 * la)
    ctx.set_line_width(2.0)
    ctx.set_dash([5, 5])
    ctx.move_to(a0[0], a0[1])
    ctx.line_to(a1[0], a1[1])
    ctx.stroke()
    ctx.set_dash([])
    grow = ramp(u, 0.6, 1.1)
    b0 = proj(c0 - 2.3 * grow * mu)
    b1 = proj(c0 + 2.3 * grow * mu)
    if grow > 0.02:
        ctx.set_source_rgba(col[0], col[1], col[2], la)
        ctx.set_line_width(5)
        ctx.set_source_rgba(col[0], col[1], col[2], la)
        ctx.move_to(b0[0], b0[1])
        ctx.line_to(b1[0], b1[1])
        ctx.stroke()
        for (p, q) in ((b1, b0), (b0, b1)):
            angh = math.atan2(p[1] - q[1], p[0] - q[0])
            ctx.save()
            ctx.translate(p[0], p[1])
            ctx.rotate(angh)
            ctx.move_to(4, 0)
            ctx.line_to(-18, -10)
            ctx.line_to(-14, 0)
            ctx.line_to(-18, 10)
            ctx.close_path()
            ctx.set_source_rgba(col[0], col[1], col[2], la)
            ctx.fill()
            ctx.restore()
        tip = b1 if b1[1] < b0[1] else b0
        text(ctx, tip[0] + 14, tip[1] - 6, "$μ$", 36, INK, la)
    # place the site label where it stays clear of the dipole arrow
    pa_, pb_ = proj(c0 - 2.3 * mu), proj(c0 + 2.3 * mu)

    def seg_dist(px, py):
        ax_, ay_, bx_, by_ = pa_[0], pa_[1], pb_[0], pb_[1]
        vx, vy = bx_ - ax_, by_ - ay_
        tt = clamp(((px - ax_) * vx + (py - ay_) * vy) / (vx * vx + vy * vy))
        return math.hypot(px - ax_ - tt * vx, py - ay_ - tt * vy)
    cands = [(40, 96, "l"), (-40, 96, "r"), (52, -64, "l"), (-52, -64, "r")]
    dx_, dy_, anc = max(cands, key=lambda c: seg_dist(ex + c[0] + (45 if c[2] == "l" else -45), ey + c[1] - 10))
    lx, ly = ex + dx_, ey + dy_
    src(ctx, SLATE, 0.7 * la)
    ctx.set_line_width(1.6)
    ctx.move_to(ex + 0.18 * dx_, ey + 0.18 * dy_)
    ctx.line_to(lx - (6 if anc == "l" else -6) * 0, ly - (26 if dy_ > 0 else -6))
    ctx.stroke()
    text(ctx, lx, ly, f"{st['site']} 1s", 30, INK, la, anc)

    # ---------------------------------------------------------- state card
    X0 = 812
    text(ctx, X0, 92, "core hole", 26, SLATE, la)
    text(ctx, X0, 130, SITE_NAME[st["site"]], 32, INK, la)
    text(ctx, X0, 178, "final state", 26, SLATE, la)
    text(ctx, X0, 216, f"MO {st['mo']}, {st['en']:.1f} eV", 32, INK, la)
    # side-view angle glyph: ring edge-on, normal dashed, dipole at theta
    gx, gy = 980, 382
    src(ctx, DEEP, la)
    ctx.set_line_width(8)
    ctx.move_to(gx - 120, gy)
    ctx.line_to(gx + 120, gy)
    ctx.stroke()
    text(ctx, gx + 128, gy + 8, "plane", 24, SLATE, la)
    src(ctx, SLATE, 0.8 * la)
    ctx.set_line_width(2)
    ctx.set_dash([5, 5])
    ctx.move_to(gx, gy + 110)
    ctx.line_to(gx, gy - 118)
    ctx.stroke()
    ctx.set_dash([])
    text(ctx, gx + 8, gy - 122, "normal", 24, SLATE, la)
    tr = math.radians(th) * ramp(u, 0.6, 1.1)
    L = 100
    ux, uy = math.sin(tr), -math.cos(tr)
    ctx.set_source_rgba(col[0], col[1], col[2], la)
    ctx.set_line_width(5)
    ctx.move_to(gx - L * ux, gy - L * uy)
    ctx.line_to(gx + L * ux, gy + L * uy)
    ctx.stroke()
    ctx.new_path()
    src(ctx, CLAY, 0.85 * la)
    ctx.set_line_width(2.4)
    ctx.arc(gx, gy, 52, -math.pi / 2, -math.pi / 2 + tr)
    ctx.stroke()
    text(ctx, gx - 14, gy - 58, f"{math.degrees(tr):.0f}°", 30, CLAY, la, "r")
    text(ctx, X0, 548, "dipole tilted from the normal", 26, SLATE, la)

    # ---------------------------------------------------------- spectrum
    AXS.frame(ctx, xticks=(285, 290, 295, 300), xlabel=None, size=28)
    text(ctx, (AXS.x0 + AXS.x1) / 2, AXS.y1 + 70, "Photon energy (eV)", 28, SLATE, 1.0, "c")
    text(ctx, AXS.x0 - 22, (AXS.y0 + AXS.y1) / 2 + 6, "DFT", 24, SLATE, 0.9, "c", rotate=-math.pi / 2)
    pts = AXS.pts(EG, ENV)
    fill_under(ctx, pts, AXS.y1, SLATE, 0.10)
    polyline(ctx, pts, SLATE, 2.2, 0.7)
    cp = AXS.pts(EG, CL_ENV[st["cluster"]])
    fill_under(ctx, cp, AXS.y1, CLAY, 0.35 * la)
    polyline(ctx, cp, CLAY, 2.6, la)
    xs = AXS.X(st["en"])
    src(ctx, CLAY, la)
    ctx.set_line_width(3)
    ctx.move_to(xs, AXS.y1)
    ctx.line_to(xs, AXS.y0 - 4)
    ctx.stroke()
    text(ctx, xs, AXS.y0 - 14, f"cluster {st['cluster']}", 24, CLAY, la, "c")
    return surf
