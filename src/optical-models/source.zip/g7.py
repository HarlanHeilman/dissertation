"""GIF 7. Lorentz (damped driven oscillator) against Gaussian-Dawson, equal peak beta and FWHM.
Left, one spectrum panel with beta (solid) and its Kramers-Kronig partner delta (dashed) for both.
Right, the equal-aspect complex plane, a circle for the Lorentzian and a wider loop for the Gaussian."""
import math
import numpy as np
from style import *
import layout as L
import g6

DUR = L.DUR
SIZE = L.SIZE
EG = g6.EG
BASES = [g6.BASES[0], g6.BASES[1]]
AX = Axes(*L.AX_BOX, (g6.ELO, g6.EHI), (-0.72, 1.12))
_XL = (-0.80, 0.80)
_YT, UNIT = L.cp_ylim(_XL)
CP = Axes(*L.CP_BOX, _XL, (0, _YT))
T0, T1 = L.T0, L.T1
FADE = L.FADE
CUM = g6.CUM


def energy(t):
    u = clamp((t - T0) / (T1 - T0))
    u = 0.5 - 0.5 * math.cos(math.pi * u)
    return float(np.interp(u, CUM, EG))


at = g6.at


def frame(t):
    surf, ctx = new_frame(*SIZE)
    E = energy(t)
    fd = 1 - ramp(t, *FADE)
    ca = fd * ramp(t, 0.0, 0.35)
    m = EG <= E

    # legend
    for k, (name, sub, col, B, D) in enumerate(BASES):
        x = L.LEG_X[k]
        text(ctx, x, L.LEG_Y[0], name, 36, col)
        text(ctx, x, L.LEG_Y[1], sub, 28, SLATE, 0.95)

    # spectrum panel
    AX.frame(ctx, xticks=(282, 285, 288), xlabel="Photon energy (eV)", size=32, zero=0.0)
    for name, sub, col, B, D in BASES[::-1]:
        if m.sum() > 1:
            pb = AX.pts(EG[m], B[m])
            fill_under(ctx, pb, AX.Y(0), col, 0.10 * fd)
            polyline(ctx, pb, col, 5.0, fd)
            polyline(ctx, AX.pts(EG[m], D[m]), col, 3.4, 0.9 * fd, dash=[10, 7])
    la = fd * ramp(t, T1 + 0.1, T1 + 0.6)
    text(ctx, AX.X(285.5), AX.Y(0.98), "$β$", 40, INK, la)
    text(ctx, AX.X(286.0), AX.Y(-0.22), "$δ$", 40, INK, la)
    text(ctx, AX.X(281.3), AX.Y(0.14), "Lorentz $β$ tails", 28, INK, la)
    cx = AX.X(E)
    src(ctx, CLAY, 0.85 * ca)
    ctx.set_line_width(2.4)
    ctx.set_dash([6, 6])
    ctx.move_to(cx, AX.y0)
    ctx.line_to(cx, AX.y1)
    ctx.stroke()
    ctx.set_dash([])
    for name, sub, col, B, D in BASES:
        for arr in (B, D):
            ctx.new_path()
            src(ctx, col, ca)
            ctx.arc(cx, AX.Y(at(arr, E)), 6.5, 0, 2 * math.pi)
            ctx.fill()

    # complex plane
    x0 = CP.X(0.0)
    src(ctx, SLATE, 0.9)
    ctx.set_line_width(3)
    ctx.move_to(CP.x0, CP.y1)
    ctx.line_to(CP.x1, CP.y1)
    ctx.stroke()
    ctx.move_to(x0, CP.y1)
    ctx.line_to(x0, CP.y0)
    ctx.stroke()
    arrow_head(ctx, CP.x1 + 4, CP.y1, 0, 16, SLATE, 0.9)
    arrow_head(ctx, x0, CP.y0 - 4, -math.pi / 2, 16, SLATE, 0.9)
    text(ctx, CP.x1 + 10, CP.y1 + 46, "Re $n$ − 1", 32, SLATE, 1.0, "r")
    text(ctx, x0 + 16, CP.y0 + 14, "Im $n$", 32, SLATE, 1.0, "l")
    for name, sub, col, B, D in BASES[::-1]:
        if m.sum() > 1:
            polyline(ctx, CP.pts(-D[m], B[m]), col, 4.6, fd)
    for name, sub, col, B, D in BASES[::-1]:
        px, py = CP.X(-at(D, E)), CP.Y(at(B, E))
        glow(ctx, px, py, 22, col, 0.35 * ca)
        ctx.new_path()
        src(ctx, col, ca)
        ctx.arc(px, py, 9, 0, 2 * math.pi)
        ctx.fill()
    text(ctx, CP.X(0.0), CP.Y(0.5) + 12, "circle", 28, INK, la, "c")
    text(ctx, CP.X(-0.62), CP.Y(0.96), "wider", 28, CRIMSON, la, "r")
    text(ctx, CP.x0, CP.y1 + 46, "slow $δ$ tails keep both ends open", 28, SLATE, la, "l")
    if la > 0.01:
        cx0, cy0, r = CP.X(0.0), CP.Y(0.5), 0.5 * UNIT + 26
        ctx.new_path()
        src(ctx, SLATE, 0.6 * la)
        ctx.set_line_width(2)
        th0, th1 = math.radians(-35), math.radians(-145)
        ctx.arc_negative(cx0, cy0, r, th0, th1)
        ctx.stroke()
        arrow_head(ctx, cx0 + r * math.cos(th1), cy0 + r * math.sin(th1), th1 - math.pi / 2, 14, SLATE, 0.6 * la)
    return surf
