import sys, importlib
from PIL import Image
mod = importlib.import_module(sys.argv[1]); ts=[float(x) for x in sys.argv[2:]]
ims=[]
for t in ts:
    s=mod.frame(t); s.write_to_png(f"/tmp/{sys.argv[1]}_{t}.png"); ims.append(Image.open(f"/tmp/{sys.argv[1]}_{t}.png"))
w,h=ims[0].size; n=len(ims); cols=2; rows=(n+1)//2
sheet=Image.new("RGB",(w*cols//2,h*rows//2),"white")
for i,im in enumerate(ims): sheet.paste(im.resize((w//2,h//2)),((i%cols)*w//2,(i//cols)*h//2))
sheet.save(f"/tmp/{sys.argv[1]}_sheet.png")
